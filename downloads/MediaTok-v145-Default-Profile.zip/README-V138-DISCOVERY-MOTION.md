# MediaTok v138 — animated discovery

Every medium in Default/Nova now has its own three-cover stage, composition, accent, heading and motion: all media, anime, films, TV, manga, novels, webnovels, light novels, comics, games and visual novels. Grouped discovery pages use the selected medium’s scene.

Covers open details and use shared artwork recovery. Pause/resume and reduced-motion support are included. Fixed poster geometry prevents layout shifts. Other site skins retain their existing designs.

Includes v137 poster recovery and header scrolling fixes. Service worker cache updated. Deploy Worker and public assets together using existing deployment instructions. No live deployment performed.

Validation: tests/v138-discovery.py checks all 11 scenes at 1440px and 390px, cover types, bounds, actions, pause/resume and reduced motion. tests/v137-browser.py and tests/v137-artwork.mjs cover poster/scroll regressions. Tests use controlled image-provider fixtures; live provider availability remains unverified.
