# v139 artwork and search sizing
- Added strict-title Wikipedia page-image fallback for light novels and webnovels. Works only for pages with relevant descriptive text and usable thumbnails. No guarantee a specific title has a thumbnail.
- Handles the common spelling variant “Musuko Tensi” when searching Mushoku Tensei cover art.
- Bounds search poster sizing to 2:3 cards, rather than letting asynchronous image results stretch containers.
- Updated artwork API cache version and service-worker cache.
- No database changes. Existing TMDB settings stay intact.
- Verify at runtime using `Mushoku Tensei`, `Lord of the Mysteries`, and searches across multiple media types. External artwork has not been live-verified.
