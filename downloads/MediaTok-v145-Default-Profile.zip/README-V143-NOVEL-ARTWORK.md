# MediaTok v143 – Novel artwork recovery

Built from v142. No D1 migrations. No new API key.

- Loosened novel cover title matching for publisher volume labels (such as `Mushoku Tensei: Jobless Reincarnation (Light Novel) Vol. 1`) without accepting unrelated spin-offs.
- Added direct Wikipedia image lookup for Lord of Mysteries and Mushoku Tensei, and a Google Books lookup of the publisher edition for Mushoku Tensei.
- Kept AniList, Jikan, MangaUpdates, Google Books generic, Open Library and Wikipedia keyword search as alternative cover sources.
- Adjusted novel artwork timeouts, front-end timeout, and negative cache retry. Service Worker and Worker artwork cache version updated.
- Search API, site layouts, D1 schema, and account data unchanged.

## Validate after deploy

1. Open `/api/search/cover?type=light-novel&q=Mushoku%20Tensei` and `/api/search/cover?type=webnovel&q=Lord%20of%20Mysteries`; confirm `cover` or `alternates` contain usable image URLs.
2. Search those titles in Explore and test visible posters. If the API returns image links but pictures still don't display, inspect the network image response: browser/CORS/hotlink/CDN issues differ from missing metadata.
3. If the API returns empty after deploying the correct version, record the HTTP response and Worker logs; remote provider availability was not independently verified during package creation.
4. No API key is required specifically for these additional book/novel sources. TMDB_API_KEY remains for film and TV.

Only title-matched artwork is displayed. Cover availability remains dependent on providers; external APIs could still block requests.
