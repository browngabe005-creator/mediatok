// Return ALL already-settled cover sources when time runs out, even if one
// third-party API is stalled. Pure, testable logic; no user data or API keys.
export function collectNovelCovers(tasks,{timeoutMs=5500,graceMs=400}={}) {
  return new Promise(resolve=>{
    let completed=0, finished=false, settling=null;
    const successes=new Map();
    const hard=setTimeout(()=>finish(),timeoutMs);
    const finish=()=>{
      if(finished)return;
      finished=true;clearTimeout(hard);clearTimeout(settling);
      const urls=[...new Set([...successes.entries()].sort((a,b)=>a[0]-b[0])
        .flatMap(([,v])=>v))].filter(v=>typeof v==='string' && /^https:\/\//i.test(v));
      resolve({urls,completed,timedOut:completed<tasks.length});
    };
    if(!tasks.length){finish();return;}
    tasks.forEach((task,i)=>Promise.resolve(task).then(value=>{
      if(finished)return;
      if(Array.isArray(value) && value.length){
        successes.set(i,value);
        if(!settling)settling=setTimeout(finish,graceMs);
      }
    },()=>{}).finally(()=>{
      if(finished)return;
      completed++;
      if(completed===tasks.length)finish();
    }));
  });
}

// These are *backup candidates*, not proof an image is currently online.
// Include only exact known works so a manga/anime adaptation isn't used as a
// prose novel cover. Browser image onerror handles broken publisher/CDN URLs.
export function knownNovelCovers(type,title){
  const n=String(title||'').normalize('NFKD').toLowerCase().replace(/[^a-z0-9]/g,'');
  if(type==='light-novel' && /^(?:musukotensi|mushokutensei(?:joblessreincarnation)?(?:lightnovel)?(?:vol(?:ume)?[0-9]+)?)$/.test(n))
    return [
      'https://covers.openlibrary.org/b/isbn/9781642751383-L.jpg?default=false',
      'https://covers.libro.fm/9798888439524_400.jpg'
    ];
  if(type==='webnovel' && (n==='lordofmysteries'||n==='lordofthemysteries'))
    return ['https://book-pic.webnovel.com/bookcover/11022733006234505'];
  return [];
}
