// Separate, testable novel-cover matching. This file uses no network or user data.
// A title with a volume / edition suffix can be the same work; a new spin-off is not.
export function normalizeNovelTitle(value) {
  return String(value||'').normalize('NFKD').toLowerCase().replace(/[^a-z0-9]+/g,'');
}
export function novelArtworkAliases(title,type) {
  const text=String(title||'').trim();
  const norm=normalizeNovelTitle(text);
  const aliases=[text];
  if(type==='light-novel' && /^(?:musukotensi|mushokutensei(?:(?:joblessreincarnation|isekaiittarahonkidasu)(?:(?:light)?novel)?(?:vol(?:ume)?[0-9]+)?)?)$/.test(norm))
    aliases.push('Mushoku Tensei','Mushoku Tensei: Jobless Reincarnation','Mushoku Tensei Isekai Ittara Honki Dasu');
  if(type==='webnovel' && /^(?:lordofthemysteries|lordofmysteries)$/.test(norm))
    aliases.push('Lord of Mysteries','Lord of the Mysteries');
  return [...new Set(aliases)].filter(Boolean);
}
export function novelEditionTitleMatch(title, aliases) {
  const n=normalizeNovelTitle(title);if(!n)return false;
  return (aliases||[]).some(alias=>{
    const base=normalizeNovelTitle(alias);
    if(!base)return false;
    if(n===base)return true;
    if(base.length<7||!n.startsWith(base))return false;
    const tail=n.slice(base.length);
    // Accept published editions of the same title, not unrelated side stories.
    return /^(?:(?:light|web|official)?novel)?(?:volume|vol|book|part|edition|omnibus)\d*/.test(tail)
      || /^\d{1,3}$/.test(tail)
      || (base==='mushokutensei' && /^joblessreincarnation(?:(?:light)?novel)?(?:vol(?:ume)?\d*)?/.test(tail));
  });
}
export function matchedBookImages(items, aliases){
  const found=(items||[]).filter(b=>novelEditionTitleMatch(b?.volumeInfo?.title,aliases)&&b?.volumeInfo?.imageLinks);
  // Prefer the first numbered edition when more than one volume matches.
  found.sort((a,b)=>{
    const vol=x=>Number(String(x?.volumeInfo?.title||'').match(/(?:vol(?:ume)?|book)\.?\s*(\d+)/i)?.[1]||99);
    return vol(a)-vol(b);
  });
  const urls=[];
  for(const item of found.slice(0,3)){
    const img=item.volumeInfo.imageLinks;
    for(const url of [img.extraLarge,img.large,img.medium,img.thumbnail,img.smallThumbnail]){
      if(typeof url==='string'&&/^https?:\/\//i.test(url))urls.push(url.replace(/^http:/i,'https:'));
    }
  }
  return [...new Set(urls)];
}
export function matchedMangaUpdatesArtwork(results,aliases){
  for(const item of results||[]){
    const r=item?.record?.series||item?.series||item?.record||item;
    const titles=[r?.title,r?.series_title,...(Array.isArray(r?.associated)?r.associated.map(x=>typeof x==='string'?x:x?.title):[])];
    if(!titles.some(name=>novelEditionTitleMatch(name,aliases)))continue;
    const img=r?.image?.url||r?.image||{};
    const variants=[img?.original,img?.thumb,typeof img==='string'?img:'',r?.image_url];
    return [...new Set(variants.filter(x=>typeof x==='string'&&/^(https?:)?\/\//i.test(x)).map(x=>x.startsWith('//')?'https:'+x:x.replace(/^http:/i,'https:')))];
  }
  return [];
}
