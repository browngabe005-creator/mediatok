# MediaTok v141 — Novel artwork recovery and Explore hover

- Preserves the working search and row spacing from v140.
- Wires MangaUpdates into **artwork-only** lookup for light novels and webnovels (v140 added it to search only).
- Uses spelling/title aliases for cover retrieval, including Mushoku Tensei and both Lord of Mysteries titles.
- Prioritizes the new artwork endpoint for novels rather than waiting for older catalog cover routes.
- Preserves the existing retry behavior for failed poster image URLs.
- Applies smooth, low-cost lift and subtle outline/shadow only to default Nova search cards; no 3D rotation, oversized zoom or perpetual animations. Supports reduced motion.
- Bumps cover/service-worker cache versions. No new secrets, API keys or database migrations.

Limitations: Provider images depend on upstream availability, title matching, hotlink policies and CDN access; some novel entries may remain without art. Nothing here changes stored user media or existing profile layouts.

Verify: Search **Mushoku Tensei** under Light novels and **Lord of Mysteries** under Webnovels. Check both a title-matched poster and hover/keyboard and mobile behavior. For failures inspect `/api/search/cover?type=webnovel&q=Lord%20of%20Mysteries` and the returned image URL/network status.
