/* Presence uses expiring 90-second leases, renewed only by visible signed-in tabs. */
(()=>{
 let busy=false,friendName='',friendHTML='';
 async function refresh(){
  if(document.hidden||busy)return;busy=true;
  try{
   if(state.me)await api('/api/presence',{method:'POST',body:'{}'}).catch(()=>null);
   const root=document.querySelector('.nova-profile');
   const name=state.profile?.name;
   if(!root||!name)return;
   const data=await api('/api/presence?name='+encodeURIComponent(name)).catch(()=>({isOnline:false}));
   if(state.profile?.name!==name||!root.isConnected)return;
   root.querySelectorAll('.nova-online-dot').forEach(dot=>dot.hidden=!data.isOnline);
   const box=root.querySelector('.nova-friend-avatars');
   if(!box)return;
   if(friendName!==name){
    const results=await Promise.all(['following','followers'].map(kind=>api('/api/profile/'+encodeURIComponent(name)+'/'+kind)));
    const people=[...new Map(results.flatMap(r=>r.users||[]).map(u=>[u.name,u])).values()];
    friendHTML=people.length?people.slice(0,4).map(u=>`<a href="${userLink(u.name)}" title="${esc(u.global_name||u.name)}">${avatar({name:u.name,avc:u.avatar_url||u.avc},54)}</a>`).join('')+(people.length>4?`<button onclick="showProfileConnections('following')">+${people.length-4}</button>`:''):'<span>No connections yet.</span>';
    friendName=name;
   }
   if(box.isConnected)box.innerHTML=friendHTML;
  }catch{}finally{busy=false;}
 }
 const observer=new MutationObserver(()=>{
  const box=document.querySelector('.nova-friend-avatars');
  if(box&&friendName===state.profile?.name&&box.innerHTML!==friendHTML)box.innerHTML=friendHTML;
  if(document.querySelector('.nova-online-dot')&&!busy) schedule();
 });
 let timer;function schedule(){clearTimeout(timer);timer=setTimeout(refresh,200);}
 addEventListener('DOMContentLoaded',()=>{observer.observe(document.getElementById('app')||document.body,{childList:true,subtree:true});schedule();});
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)refresh();});
 setInterval(refresh,30000);
})();
