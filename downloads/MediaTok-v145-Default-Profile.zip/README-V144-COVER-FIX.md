# MediaTok v144 – novel cover reliability

Based on v143. No database changes, no new required API key.

- Fixes a concrete timeout bug: the old Promise.race returned **zero covers** if any provider remained pending at the deadline even when another provider had already provided an image. v144 collects completed results immediately and settles shortly after the first valid source.
- Adds *alternate* publisher-catalog image candidates for the exact titles Mushoku Tensei and Lord of Mysteries. These URLs are fallbacks, not guaranteed live images.
- Keeps the novel placeholder's title and type so it can be retried if a previous image fails.
- Bumps cover cache identifier and service-worker registration; `/api/health` now reports `version: "v144"` to verify the deployed Worker is actually updated.
- Keeps existing search and user data unchanged.

## Verification
Run `node tests/v144-cover-recovery.mjs`. For the live deployed Worker, open `/api/search/cover?type=light-novel&q=Mushoku%20Tensei` and `/api/search/cover?type=webnovel&q=Lord%20of%20Mysteries` and check that the response includes a `cover` link. Then test that the image URL itself returns image content, and the browser is loading the latest files.

This package cannot guarantee every webnovel cover is available: upstream providers may not index it or may restrict image delivery.
