from pathlib import Path
from playwright.sync_api import sync_playwright
import re,json
root=Path(__file__).resolve().parents[1]/'public'
html=(root/'index.html').read_text()
html=re.sub(r'<script[^>]+src="([^"]+)"[^>]*></script>',lambda m:'<script>'+((root/m[1].split('?')[0].lstrip('/')).read_text() if m[1].startswith('/') and (root/m[1].split('?')[0].lstrip('/')).exists() else '')+'</script>',html)
html=re.sub(r'<link[^>]+href="([^"]+)"[^>]*>',lambda m:'<style>'+(root/m[1].split('?')[0].lstrip('/')).read_text()+'</style>' if m[1].startswith('/') and m[1].split('?')[0].endswith('.css') else '',html)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for w in [1672,1024,390]:
  page=b.new_page(viewport={'width':w,'height':1000})
  page.route('**/*',lambda r:r.abort())
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(html,wait_until='domcontentloaded')
  page.evaluate('''()=>{const u={id:1,name:'BlackCat',globalName:'BlackCat',stats:{total:47},followers:1,following:3,joined:1710000000000,socials:{},accent:'#ac8fff'};state.me=u;state.profile=u;state.view='profile';state.profileTab='overview';state.profileLogs=Array.from({length:12},(_,i)=>({id:i,mediaKey:'film:'+i,mediaType:i%2?'film':'webnovel',title:['Lord of Mysteries','Omniscient Reader','Terminator','Dune'][i%4],status:i<5?'Planning':i===5?'In progress':'Completed',rating:i>5?8:null,updatedAt:Date.now()}));api=async(path)=>path.includes('presence')?{isOnline:true}:{users:[{name:'Alice'}]};document.getElementById('app').innerHTML=mtNovaShell(mtNovaProfilePage(u),false,true);}''')
  page.wait_for_timeout(600)
  metrics=page.evaluate('''()=>({width:innerWidth,scroll:document.documentElement.scrollWidth,panels:document.querySelectorAll('.nova-reference-grid>.nova-profile-section').length,dot:document.querySelector('.nova-online-dot')?.hidden,grid:getComputedStyle(document.querySelector('.nova-reference-grid')).gridTemplateColumns})''')
  print(w,json.dumps(metrics),errors[:3])
  assert metrics['panels']==6
  assert metrics['scroll']<=w+1
  assert metrics['dot']==False
  page.evaluate("state.profileTab='activity'; document.getElementById('app').innerHTML=mtNovaShell(mtNovaProfilePage(state.profile),false,true)")
  assert page.locator('.nova-profile-event').count()==7
  page.close()
 b.close()
