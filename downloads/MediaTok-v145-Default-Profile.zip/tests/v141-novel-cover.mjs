import assert from 'node:assert/strict';
import {readFile,writeFile,unlink} from 'node:fs/promises';
// Node cannot import the Cloudflare Durable Object runtime; swap only that class
// in a temporary test copy. All other Worker routes remain the production code.
const workerPath=new URL('../src/worker.js',import.meta.url);
const stubPath=new URL('../src/.worker-cover-test.mjs',import.meta.url);
const content=(await readFile(workerPath,'utf8')).replace("export { ForumLiveRoom } from './live-chat.js';",'export class ForumLiveRoom {}');
await writeFile(stubPath,content);
let worker;
try{worker=(await import(stubPath.href)).default;}finally{await unlink(stubPath);}


const originalFetch=globalThis.fetch;
const json=value=>new Response(JSON.stringify(value),{headers:{'Content-Type':'application/json'}});
const requestCover=async(type,title)=>{
 const response=await worker.fetch(new Request('https://mediatok.org/api/search/cover?'+new URLSearchParams({type,q:title,alternate:'1'})),{DB:{prepare(){throw Error('No database expected');}}},{waitUntil(){}});
 assert.equal(response.status,200,'cover lookup should not depend on database');
 return response.json();
};
try {
  const calls=[];
  globalThis.fetch=async(u,opts={})=>{
    const uri=String(u);calls.push({uri,body:opts.body});
    if(uri.includes('api.mangaupdates.com'))return json({results:[{record:{title:'Lord of Mysteries',image:{url:{original:'https://www.mangaupdates.com/test-lord-cover.jpg'}}}}]});
    if(uri.includes('en.wikipedia.org'))return json({query:{pages:{}}});
    return json({data:{Page:{media:[]}},docs:[],items:[]});
  };
  const lord=await requestCover('webnovel','Lord of the Mysteries');
  assert.equal(lord.cover,'https://www.mangaupdates.com/test-lord-cover.jpg');
  assert(calls.some(x=>x.uri.includes('api.mangaupdates.com')));
  assert(calls.some(x=>x.uri.includes('api.mangaupdates.com')&&String(x.body).includes('Lord of Mysteries')));

  globalThis.fetch=async(u)=>{
    if(String(u).includes('graphql.anilist.co'))return json({data:{Page:{media:[{title:{english:'Mushoku Tensei: Jobless Reincarnation',romaji:'Mushoku Tensei'},coverImage:{large:'https://s4.anilist.co/test-mushoku-cover.jpg'}}]}}});
    return json({results:[],docs:[],items:[],data:{}});
  };
  const mushoku=await requestCover('light-novel','Musuko Tensi');
  assert.equal(mushoku.cover,'https://s4.anilist.co/test-mushoku-cover.jpg');

  globalThis.fetch=async(u)=>{
    if(String(u).includes('api.mangaupdates.com'))return json({results:[{record:{title:'Unrelated Story',image:{url:{original:'https://www.mangaupdates.com/unrelated.jpg'}}}}]});
    return json({results:[],docs:[],items:[],data:{Page:{media:[]}},query:{pages:{}}});
  };
  const unmatched=await requestCover('webnovel','Not A Real Novel');
  assert.equal(unmatched.cover,'','unrelated cover must not be used');
  console.log('v141: mock MangaUpdates alias, AniList misspelling, unmatched art -> PASS');
}finally{globalThis.fetch=originalFetch;}
