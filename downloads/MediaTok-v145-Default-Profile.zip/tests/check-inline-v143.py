from html.parser import HTMLParser
from pathlib import Path
import subprocess, tempfile
class Parser(HTMLParser):
 def __init__(self): super().__init__(); self.typ=None;self.chunks=[];self.scripts=[]
 def handle_starttag(self,tag,attrs):
  if tag=='script': self.typ=dict(attrs).get('type','javascript');self.chunks=[]
 def handle_data(self,data):
  if self.typ is not None:self.chunks.append(data)
 def handle_endtag(self,tag):
  if tag=='script' and self.typ is not None:
   if self.typ in ('javascript','text/javascript','module',''):self.scripts.append(''.join(self.chunks))
   self.typ=None
p=Parser();p.feed(Path(__file__).resolve().parent.parent.joinpath('public/index.html').read_text())
for i,chunk in enumerate(p.scripts):
 if len(chunk)<3: continue
 with tempfile.NamedTemporaryFile(suffix='.js',mode='w',delete=False) as f:f.write(chunk); fn=f.name
 r=subprocess.run(['node','--check',fn],capture_output=True,text=True)
 Path(fn).unlink(missing_ok=True)
 if r.returncode:print(f'Inline script {i} FAILED:',r.stderr[:1400]);raise SystemExit(1)
print('All',len(p.scripts),'inline JS script blocks parse successfully')
