import assert from 'node:assert/strict';
import worker from '../src/worker.js';
const rawFetch=globalThis.fetch;
const seen=[];
globalThis.fetch=(url, options={})=>{
 const path=String(url);seen.push(path);
 if(path.startsWith('https://en.wikipedia.org/w/api.php')&&path.includes('titles=')) {
  return Promise.resolve(new Response(JSON.stringify({query:{pages:{'1':{title:path.includes('Mushoku')?'Mushoku Tensei':'Lord of Mysteries',thumbnail:{source:'https://upload.wikimedia.org/commons/valid.jpg'}}}}}),{status:200,headers:{'Content-Type':'application/json'}}));
 }
 // Every competing provider hangs until aborted. Previously this caused
 // Promise.race(allSettled, timeout) to discard a successful Wikipedia cover.
 return new Promise((resolve,reject)=>{
  const abort=()=>reject(new Error('aborted'));
  if(options.signal?.aborted)abort(); else options.signal?.addEventListener('abort',abort,{once:true});
 });
};
const DB={prepare(){return {bind(){return {first:async()=>null}}}}};
try{
 for(const [type,name] of [['light-novel','Mushoku Tensei'],['webnovel','Lord of Mysteries']]){
  const url='https://mediatok.org/api/search/cover?'+new URLSearchParams({type,q:name});
  const start=Date.now();
  const r=await worker.fetch(new Request(url),{DB,ASSETS:{fetch:()=>new Response('asset')}},{waitUntil(){}});
  const body=await r.json();
  assert.equal(r.status,200,`${name} endpoint status`);
  assert.equal(body.cover,'https://upload.wikimedia.org/commons/valid.jpg',`${name} should keep the successful fast source`);
  assert.ok(Date.now()-start<3800,`${name} should not wait out every slow source`);
  console.log(`${type} ${name}: success in ${Date.now()-start}ms`);
 }
}finally{globalThis.fetch=rawFetch;}
console.log('v144 Worker endpoint tests passed');
