import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {novelArtworkAliases,novelEditionTitleMatch,matchedBookImages,matchedMangaUpdatesArtwork} from '../src/novel-artwork-v143.js';

const aliases=novelArtworkAliases('Musuko Tensi','light-novel');
assert(aliases.includes('Mushoku Tensei'));
assert(novelEditionTitleMatch('Mushoku Tensei: Jobless Reincarnation (Light Novel) Vol. 1',aliases));
assert(novelEditionTitleMatch('Lord of Mysteries',novelArtworkAliases('Lord of the Mysteries','webnovel')));
assert(!novelEditionTitleMatch('Mushoku Tensei: Roxy Gets Serious', aliases));
assert(!novelArtworkAliases('Mushoku Tensei: Roxy Gets Serious','light-novel').includes('Mushoku Tensei'));
const book=matchedBookImages([{volumeInfo:{title:'Mushoku Tensei: Jobless Reincarnation (Light Novel) Vol. 1',imageLinks:{thumbnail:'http://books.google.com/sample.jpg'}}}],aliases);
assert.deepEqual(book,['https://books.google.com/sample.jpg']);
assert.deepEqual(matchedMangaUpdatesArtwork([{record:{title:'Lord of Mysteries',image:{url:{original:'https://www.mangaupdates.com/sample.jpg'}}}}],novelArtworkAliases('Lord of the Mysteries','webnovel')),['https://www.mangaupdates.com/sample.jpg']);

// Execute the real Worker route against isolated provider responses.
const worker=readFileSync(new URL('../src/worker.js',import.meta.url),'utf8');
const start=worker.indexOf('  if (url.pathname === "/api/search/cover" && method === "GET") {');
const end=worker.indexOf('  if (url.pathname === "/api/search/anilist" && method === "GET") {', start);
assert(start>=0&&end>start,'Cover API handler must be present');
const AsyncFunction=Object.getPrototypeOf(async function(){}).constructor;
const route=new AsyncFunction('url','method','mediaTypes','env','fetch','providerCooldown','backoffProvider','json','novelArtworkAliases','novelEditionTitleMatch','matchedMangaUpdatesArtwork','matchedBookImages',worker.slice(start,end));
const reports=[];
function mockFetch(url,options){
  const u=String(url);
  if(u.includes('/books/v1/volumes/qTWTugEACAAJ'))return Promise.resolve(new Response(JSON.stringify({volumeInfo:{title:'Mushoku Tensei: Jobless Reincarnation (Light Novel) Vol. 1',imageLinks:{thumbnail:'https://books.google.com/mushoku-cover.jpg'}}}),{status:200}));
  if(u.includes('api.mangaupdates.com'))return Promise.resolve(new Response(JSON.stringify({results:[{record:{title:'Lord of Mysteries',image:{url:{original:'https://www.mangaupdates.com/lord-cover.jpg'}}}}]}),{status:200}));
  if(u.includes('en.wikipedia.org')&&u.includes('titles=Lord'))return Promise.resolve(new Response(JSON.stringify({query:{pages:{1:{title:'Lord of Mysteries',thumbnail:{source:'https://upload.wikimedia.org/lord-cover.jpg'}}}}}),{status:200}));
  return Promise.resolve(new Response('unavailable',{status:503}));
}
for(const [type,title,expected] of [
 ['light-novel','Mushoku Tensei','https://books.google.com/mushoku-cover.jpg'],
 ['webnovel','Lord of the Mysteries','https://www.mangaupdates.com/lord-cover.jpg']
]){
 const output=await route(new URL(`https://mediatok.org/api/search/cover?type=${type}&q=${encodeURIComponent(title)}`),'GET',new Set(['light-novel','webnovel']),{},mockFetch,async()=>false,async()=>{},x=>x,novelArtworkAliases,novelEditionTitleMatch,matchedMangaUpdatesArtwork,matchedBookImages);
 assert([output.cover,...output.alternates].includes(expected),`Expected title-matched artwork for ${title}, got ${JSON.stringify(output)}`);
 reports.push({type,title,cover:output.cover,alternates:output.alternates.length});
}
console.log('v143 novel cover assertions passed',reports);
