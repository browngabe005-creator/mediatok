from pathlib import Path
from urllib.parse import urlparse
from playwright.sync_api import sync_playwright
import json
P=Path(__file__).resolve().parents[1]/'public'
SVG='<svg xmlns="http://www.w3.org/2000/svg" width="200" height="300"><rect width="200" height="300" fill="purple"/></svg>'
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for width in [1440,390]:
  page=b.new_page(viewport={'width':width,'height':900},service_workers='block')
  errors=[];requests=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  def route(r):
   u=urlparse(r.request.url)
   if u.path.startswith('/api/'):
    requests.append(u.path)
    data={'results':[],'logs':[],'users':[],'notifications':[]}
    if u.path=='/api/feed': data=[]
    elif u.path=='/api/search/cover': data={'cover':'https://upload.wikimedia.org/test.jpg','alternates':[]}
    elif u.path.endswith('/cover'):data={'cover':'','alternates':[]}
    r.fulfill(json=data)
   elif u.hostname=='upload.wikimedia.org':r.fulfill(body=SVG,content_type='image/svg+xml')
   elif u.hostname=='test.local':
    f=P/(u.path.lstrip('/') or 'index.html')
    if f.is_file():r.fulfill(path=str(f))
    else:r.fulfill(status=404)
   else:r.fulfill(body='',content_type='application/javascript')
  page.route('**/*',route)
  page.goto('http://test.local',wait_until='domcontentloaded')
  page.wait_for_timeout(500)
  for medium in ['all','anime','film','tv','manga','novel','webnovel','light-novel','comic','game','visual-novel']:
   page.evaluate("type=>{state.feed=[];state.me=null;state.view='discover';state.type=type;state.search='';state.results=[];document.querySelector('#app').innerHTML=mtNovaDiscoverPage();scrollTo(0,0)}",medium)
   page.wait_for_timeout(100)
   assert page.locator('.discovery-poster').count()==3,medium
   if medium!='all':assert page.locator('.discovery-poster[data-type="'+medium+'"]').count()==3,medium
   assert page.evaluate('document.documentElement.scrollWidth<=innerWidth'),(width,medium)
   metrics=page.evaluate("""()=>{const h=document.querySelector('.nova-discover-hero').getBoundingClientRect();return [...document.querySelectorAll('.discovery-poster')].map(e=>{const r=e.getBoundingClientRect();return r.left>=h.left-2&&r.right<=h.right+2&&r.top>=h.top&&r.bottom<=h.bottom})}""")
   assert all(metrics),(width,medium,metrics)
   page.locator('.discovery-motion-toggle').click()
   assert page.locator('.discovery-motion-toggle').get_attribute('aria-pressed')=='true'
   assert page.evaluate("getComputedStyle(document.querySelector('.discovery-poster')).animationPlayState")=='paused'
   page.evaluate("window.openSiteMediaDetails=(...args)=>window.openedTitle=args")
   page.locator('.position-1 .discovery-poster').click()
   assert page.evaluate('window.openedTitle[1]')
   page.locator('.discovery-motion-toggle').click()
   assert page.locator('.discovery-motion-toggle').get_attribute('aria-pressed')=='false'
  page.emulate_media(reduced_motion='reduce')
  assert page.evaluate("getComputedStyle(document.querySelector('.discovery-poster')).animationName")=='none'
  assert not errors,errors
  page.emulate_media(reduced_motion='no-preference')
  page.evaluate("state.type='film';document.querySelector('#app').innerHTML=mtNovaDiscoverPage();scrollTo(0,0)")
  page.wait_for_timeout(700)
  page.screenshot(path='/workspace/work/discovery-'+str(width)+'.png')
  print(f'PASS {width}px: all 11 scenes, medium-specific artwork, overflow, pause/resume, title links, reduced motion, no JS errors',flush=True)
  page.close()
 b.close()
