# v145 — Default profile mockup and online indicator

The original/default profile now uses the supplied mockup's banner, identity badges, metrics, tabs and six overview panels: Personal Picks, Currently Into, Collection Snapshot, Watchlist, Recent Activity, and Friends & Followers. Uses the account's saved artwork, banner, profile picture and collection; the reference image's fictional content is not seeded. Other profile layouts retain their rendering.

Recent Activity reflects the viewed member's saved logs, ordered by update time. Connection previews use the existing followers/following endpoints. Existing editing, following, messaging, watchlist, media details and music controls remain available.

A green dot beside the main profile avatar indicates recent activity. Visible, signed-in tabs send a heartbeat every 30 seconds. Presence expires after 90 seconds without a heartbeat (including closing the browser, signing out or hiding all tabs). Visitors poll every 30 seconds. This is approximate presence, not an instantaneous connection monitor.

## Deploy

From the project folder, run the existing installation/deployment workflow:

```
npm install
npm run migrations:apply
npm run deploy
```

Migration `0018_profile_presence.sql` must be applied before deploying for the online indicator to work. Existing data is preserved. This package has not been deployed to a live service.

## Validation

```
node --experimental-loader ./tests/mock-cloudflare-v144-loader.mjs tests/v145-presence.mjs
python tests/v145-profile-browser.py
```

Browser checks require Python Playwright and Chromium at `/usr/bin/chromium`. They exercise six panels, profile-specific activity, the online dot, and horizontal overflow at 1672, 1024 and 390 pixels. Presence tests check authentication, heartbeat renewal and expiry.
