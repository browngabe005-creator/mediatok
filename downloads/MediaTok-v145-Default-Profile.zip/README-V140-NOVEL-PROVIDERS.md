# MediaTok v140: novel source and poster grid repair

- Added MangaUpdates public series search as an independent source for light novels and webnovels, with returned cover URLs where present. No API key is required for the public series search (subject to provider restrictions and availability).
- Existing AniList/Jikan/Google Books/Open Library/Wikipedia fallbacks remain.
- Removed `content-visibility:auto` and its reserved intrinsic card height in the Nova Explore grid. This prevents large empty gaps between poster rows after dynamic search results load.
- Cache version bumped. No database migrations.

Limitations: Public APIs do not provide a complete webnovel catalog, or guaranteed artwork for every title. MangaUpdates may not index all prose-only works. If the upstream API rejects calls, the other providers remain available.
