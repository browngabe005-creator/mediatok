# MediaTok v142 — empty Dex, cover recovery, favicon and moderation evidence

## Changes
- Dex profile: a genuinely empty Circle is omitted, including after loading an empty connections response. Empty My Stars, Next Up, Movies/TV/Anime and Books sections are no longer rendered. Layout collapses when no circle exists.
- Fixed MangaUpdates nested response extraction in both novel search and cover rescue. Corrects `results[].record.series.image.url.*` handling; retains other artwork sources. Cover cache rotated to v142. Artwork is still provider-dependent, and has not been verified against live APIs.
- Standardized browser tab icon and app manifest assets from the MediaTok logo. Service Worker cache rotated.
- Admin Portal: existing admin/owner-only security event list now contains successful email or Discord logins and new email registrations with timestamp, Cloudflare-supplied IP, reported browser family, OS and device class. Existing events and banned-user tools retained. New authentication events are pruned after 90 days by the scheduled Worker.

## Privacy and safeguards
- No covert fingerprinting, canvas/audio/font probing, third-party tracking, browser identifiers or attempts to discover unrelated Discord accounts. User agents can be faked and IP addresses can be shared. Logs are leads, not evidence of a particular person's identity. Only the OAuth-linked Discord account is known.
- **Before deployment:** Update your privacy notice to disclose these security logs and retention. Restrict admin access; preserve only necessary evidence when reporting credible abuse. Do not expose the logs publicly.
- Uses the existing `security_events` table introduced in migration 0011, so no new migration is required if that table exists. Verify migrations through 0011 were applied.

## Verify after deploying
1. Profile with zero followers and zero following: there is no Circle box or reserved right-column space. Empty Dex media profile: no placeholder collections.
2. Existing profile with people and media: Circle and normal sections still render.
3. In Explore, search `Mushoku Tensei` and `Lord of the Mysteries` and inspect `/api/search/cover?type=light-novel&q=Mushoku%20Tensei` and `/api/search/cover?type=webnovel&q=Lord%20of%20the%20Mysteries`. If `cover` is empty, the provider did not return a title-matched image; these are not guaranteed to have art.
4. Open the browser tab in a new private window and check the MediaTok icon.
5. Sign in with a test account, then open Admin Portal as owner/admin and verify login timestamp, browser, OS and IP fields, not accessible to other roles.

Admin Portal now labels recent accounts sharing the same IP and shows the OAuth-linked Discord ID only when available, for owner/admin review. These are not proof of personal identity.
