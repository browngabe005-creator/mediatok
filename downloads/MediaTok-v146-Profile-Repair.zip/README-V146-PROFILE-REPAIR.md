# v146 — Profile stability and navigation repair

Replaces the v145 default-profile styling and connection loader.

- Removes the self-observing connection HTML rewrite. Browser-normalized avatar HTML could differ from its source string, repeatedly triggering DOM mutations and freezing the profile. Connection previews now load explicitly after profile render or tab change, with bounded requests, cached results and retry UI.
- Restores the desktop left sidebar; adds an accessible mobile navigation toggle and Escape dismissal.
- Rebuilds the header in normal document flow. Names, status, biography, badges, actions and metrics wrap without overlapping. Removes the join date.
- Disables default-profile animation, transitions and poster movement.
- Fixes the current-title poster container's inherited 55px height and allows long titles to wrap.
- Retains the green online indicator, existing artwork recovery, profile tabs and editing controls. Presence failures do not block connections or profile rendering.
- Uses versioned v146 assets and a new service-worker cache to replace stale v145 assets.

Deploy the complete package using the existing deployment workflow. Run `npm run migrations:apply` before `npm run deploy`; migration 0018 is still required if not already applied. No additional migration beyond v145 is needed.

Validation: full app startup at /alice with fixture APIs and actual image/avatar markup at 1897, 1366, 1024 and 390 pixels. Checks stable connection DOM/request counts, visible sidebar or mobile menu, library navigation, watchlist/overview tabs, editor, current-title modal, full-height loaded cover, biography/badge separation, horizontal overflow, disabled animations and JavaScript errors. Authenticated presence renewal and offline-expiry tests also pass. These checks use local fixtures, not a live production account.

Run a static server for public/ on port 8765, then `python tests/v146-profile-browser.py`. Presence: `node --experimental-loader ./tests/mock-cloudflare-v144-loader.mjs tests/v145-presence.mjs`.
