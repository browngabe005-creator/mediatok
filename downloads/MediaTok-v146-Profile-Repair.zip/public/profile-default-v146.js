/* Explicit render lifecycle: never observe and rewrite our own avatar subtree. */
(()=>{
 let heartbeatAt=0,heartbeatBusy=false,presenceBusy=false;
 const cache=new Map();
 const request=(path,options={})=>api(path,{...options,signal:AbortSignal.timeout(8000)});
 async function heartbeat(){
  if(document.hidden||!state.me||heartbeatBusy||Date.now()-heartbeatAt<25000)return;
  heartbeatBusy=true;
  try{await request('/api/presence',{method:'POST',body:'{}'});heartbeatAt=Date.now();}catch{}finally{heartbeatBusy=false;}
 }
 async function presence(){
  const root=document.querySelector('.nova-profile'),name=state.profile?.name;
  if(!root||!name||document.hidden||presenceBusy)return;
  presenceBusy=true;
  try{
   await heartbeat();
   const data=await request('/api/presence?name='+encodeURIComponent(name));
   if(root.isConnected&&state.profile?.name===name)root.querySelectorAll('.nova-online-dot').forEach(dot=>dot.hidden=data.isOnline!==true);
  }catch{if(root.isConnected)root.querySelectorAll('.nova-online-dot').forEach(dot=>dot.hidden=true);}
  finally{presenceBusy=false;}
 }
 async function connections(){
  const box=document.querySelector('.nova-friend-avatars'),name=state.profile?.name;if(!box||!name)return;
  const apply=html=>{if(box.isConnected&&state.profile?.name===name)box.innerHTML=html;};
  const cached=cache.get(name);if(cached&&Date.now()-cached.at<60000){apply(cached.html);return;}
  box.textContent='Loading connections…';
  try{
   const results=await Promise.allSettled(['following','followers'].map(kind=>request('/api/profile/'+encodeURIComponent(name)+'/'+kind)));
   if(results.every(r=>r.status==='rejected'))throw Error('Unavailable');
   const people=[...new Map(results.flatMap(r=>r.status==='fulfilled'?(r.value.users||[]):[]).map(u=>[u.name,u])).values()];
   const html=people.length?people.slice(0,4).map(u=>`<a href="${userLink(u.name)}" aria-label="${esc(u.global_name||u.name)}">${avatar({name:u.name,avc:u.avatar_url||u.avc},48)}</a>`).join(''):'<span>No connections yet.</span>';
   cache.set(name,{html,at:Date.now()});apply(html);
  }catch{apply('<button type="button" onclick="mtRetryProfileConnections()">Could not load connections. Retry</button>');}
 }
 window.mtRetryProfileConnections=connections;
 window.mtProfileMounted=()=>{void presence();void connections();};
 window.mtToggleProfileNav=button=>{const shell=button.closest('.nova-app-profile');const open=shell.classList.toggle('nova-nav-open');button.setAttribute('aria-expanded',String(open));button.setAttribute('aria-label',open?'Close navigation':'Open navigation');};
 document.addEventListener('keydown',e=>{if(e.key==='Escape'){document.querySelector('.nova-nav-open')?.classList.remove('nova-nav-open');document.querySelector('.nova-menu-toggle')?.setAttribute('aria-expanded','false');}});
 document.addEventListener('visibilitychange',()=>{if(!document.hidden){void heartbeat();void presence();}});
 addEventListener('DOMContentLoaded',()=>{void heartbeat();window.mtProfileMounted();});
 setInterval(()=>{void heartbeat();void presence();},30000);
})();
