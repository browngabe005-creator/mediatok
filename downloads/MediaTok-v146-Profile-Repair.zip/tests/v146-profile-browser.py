from pathlib import Path
from playwright.sync_api import sync_playwright
import json
from urllib.parse import urlparse
ROOT=Path(__file__).resolve().parents[1]
user={'id':1,'name':'alice','globalName':'Alice','status':'Owner','bio':'Owner of Mediatok. A longer biography that must stay clear of badges and buttons.','role':'owner','avatarUrl':'https://fixture.test/avatar.png','bannerUrl':'https://fixture.test/banner.png','socials':{'profileLayout':'original'},'stats':{'total':777},'followers':9,'following':3,'joined':1790000000000}
logs=[{'id':i+1,'mediaKey':f'anime:{i}','mediaType':'anime','title':('Re:ZERO -Starting Life in Another World- Season 3' if i==5 else f'Title {i}'),'cover':'https://fixture.test/cover.png','status':'Planning' if i<5 else 'In progress' if i==5 else 'Completed','rating':8 if i>5 else None,'updatedAt':1790000000000,'progress':12} for i in range(18)]
svg='<svg xmlns="http://www.w3.org/2000/svg" width="200" height="300"><rect width="200" height="300" fill="#6d648e"/><circle cx="100" cy="100" r="50" fill="#b6a1df"/></svg>'
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for width in [1897,1366,1024,390]:
  page=b.new_page(viewport={'width':width,'height':950},service_workers='block')
  errors=[];calls=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.add_init_script("localStorage.setItem('mt_welcome_layout_v104_1','done');localStorage.setItem('mt_site_skin','default');")
  def route(r):
   url=urlparse(r.request.url);path=url.path
   if path=='/alice':return r.fulfill(content_type='text/html',body=(ROOT/'public/index.html').read_text())
   if url.hostname=='fixture.test':return r.fulfill(content_type='image/svg+xml',body=svg)
   if path.startswith('/api/'):
    calls.append(path)
    if path=='/api/me':data={'user':user}
    elif path=='/api/profile/alice':data={'user':user,'logs':logs}
    elif path.endswith('/following') or path.endswith('/followers'):data={'users':[{'name':'friend','global_name':'Friend','avatar_url':'https://fixture.test/avatar.png'}]}
    elif path=='/api/presence':data={'ok':True,'isOnline':True}
    elif path.startswith('/api/feed'):data=[]
    elif 'notifications' in path:data={'unread':0,'notifications':[]}
    elif 'cover' in path:data={'cover':'https://fixture.test/cover.png'}
    else:data={'ok':True,'items':[],'results':[]}
    return r.fulfill(json=data)
   if url.hostname!='127.0.0.1':return r.abort()
   r.continue_()
  page.route('**/*',route)
  page.goto('http://127.0.0.1:8765/alice',wait_until='domcontentloaded')
  page.wait_for_selector('.nova-friend-avatars a')
  page.wait_for_timeout(1200)
  # Real avatar markup must settle, rather than self-triggering mutation rewrites.
  page.evaluate("window.mutations=0;window.testObserver=new MutationObserver(()=>mutations++);testObserver.observe(document.querySelector('.nova-friend-avatars'),{childList:true,subtree:true})")
  page.wait_for_timeout(1500)
  assert page.evaluate('mutations')==0
  assert calls.count('/api/presence')<=2,calls
  assert not page.locator('.nova-online-dot').evaluate('(e)=>e.hidden')
  assert page.locator('.nova-reference-grid>.nova-profile-section').count()==6
  assert 'Joined' not in page.locator('.nova-profile-cover').inner_text()
  assert page.evaluate('document.documentElement.scrollWidth<=innerWidth'),width
  assert page.locator('.mt-current-poster').bounding_box()['height']>=145
  assert page.locator('.mt-current-poster img').evaluate('(e)=>e.complete&&e.naturalWidth>0')
  assert page.locator('.nova-profile-badges').bounding_box()['y']>=page.locator('.nova-profile-bio').bounding_box()['y']+page.locator('.nova-profile-bio').bounding_box()['height']
  assert not page.locator('.nova-profile').evaluate('(e)=>e.getAnimations({subtree:true}).length')
  if width<761:
   page.locator('.nova-menu-toggle').click();assert page.locator('.nova-sidebar').is_visible()
   page.keyboard.press('Escape');assert not page.locator('.nova-sidebar').is_visible()
  else:assert page.locator('.nova-sidebar').is_visible()
  page.locator(".nova-profile-tabbar button[onclick=\"setProfileTab('planning')\"]").click()
  assert page.locator('.nova-full-list .pf-poster').count()==5
  page.locator(".nova-profile-tabbar button[onclick=\"setProfileTab('overview')\"]").click()
  page.wait_for_selector('.nova-friend-avatars a')
  page.locator(".nova-current-section .nova-link").click();assert page.locator('.mt-current-modal').is_visible()
  page.locator('.mt-current-modal .md-close').click()
  page.locator(".nova-profile-actions button[onclick='openProfileEditor()']").click();assert page.locator('.modal.pe').is_visible()
  page.evaluate('closeModal()')
  assert not errors,errors
  page.screenshot(path=f'/workspace/work/v146-{width}.png',full_page=True)
  if width<761:page.locator('.nova-menu-toggle').click()
  page.locator('.nova-sidebar button[onclick="goView(\'library\')"]').click()
  page.wait_for_function("state.view==='library'")
  assert page.locator('.nova-profile').count()==0
  print('PASS',width,'real profile boot, stable avatars, navigation, tabs, editor, current covers, no overlap/overflow/animations/errors')
  page.close()
 b.close()
