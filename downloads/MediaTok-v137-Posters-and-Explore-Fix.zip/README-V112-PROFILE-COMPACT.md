# MediaTok v112 — Compact profile alignment

Focused refinements for the Future/Collection public profile based on the side-by-side reference: more compact card geometry, shorter category pocket, equal poster grid spacing, two-row featured poster, fewer competing editing controls, and a single row of Books. Anime remains in Movies & TV, while Books includes reading media only. No media entries were removed, and existing editing options remain.

Frontend changes only, no D1 migration. Visual fidelity of the live deployment is not verified by this package.
