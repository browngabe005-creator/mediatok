# MediaTok v104 – Welcome layout selector and Library error handling

- On first authenticated visit following this release, new and existing members see a two-step animated layout selector: Site (Default/Future/Anime), then Profile (Default/Future/Anime).
- Users are informed that both choices can later be changed in Settings. Successful completion is remembered **per account in this browser**; the public profile choice is saved to the account through the existing profile endpoint. An additional device may show the welcome selector once, even for an existing account.
- The Library's dashboard now displays a loading state, accepts either array, `logs` or `results` response shapes, ignores malformed entries, and surfaces server errors with retry rather than silently showing an empty page.
- No new database migrations are required.
- Updated service-worker version to prevent old cached assets from being reused.
- The welcome popup does not appear to unauthenticated visitors. It appears following sign-in or registration on the next page load.

## Verification
- Syntax checked index inline JavaScript and site-layouts-v94.js.
- Ran offline search regression test.
- Live Cloudflare authenticated database access and interactive browser sign-up flows were not available to verify in this environment.
