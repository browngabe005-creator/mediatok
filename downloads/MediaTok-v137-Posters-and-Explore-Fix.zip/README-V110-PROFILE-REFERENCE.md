# MediaTok v110 — Collection profile reference alignment

This release makes the Collection/Future profile geometry follow the user-supplied profile reference. It adds one final scoped stylesheet rather than editing the defaults for all site styles.

- Desktop: 914px rounded main profile card, 44px navigation rail, narrow unboxed community sidebar, measured 449:358 content ratio.
- My Stars: fixed first poster spanning two columns and two rows, followed by a 2x2 set of four smaller covers. Correctly targets the actual `.mt-ref-poster-slot` wrapper used by the renderer.
- Next Up: four aligned poster slots.
- Media groups: consistent four-column poster rows with fixed ratios and gutters.
- Preserves media selection, change-artwork, Arrange Sections, share and profile editing hooks. No music section is reintroduced.
- Responsive geometry and reduced-motion support.

## Verification
`python3 tests/v110-reference-layout.py` verifies desktop, tablet and mobile widths with an actual headless Chromium renderer, tests no page overflow and the featured poster span.

## Limits
The design is based on screenshots; proprietary source fonts, animation timing, and any features not represented in MediaTok code were not copied. Live authenticated functionality and pixel-identical comparison against the third-party website were not verified.

## Deploy
`npx wrangler deploy` from this extracted project directory. No D1 schema changes required.
