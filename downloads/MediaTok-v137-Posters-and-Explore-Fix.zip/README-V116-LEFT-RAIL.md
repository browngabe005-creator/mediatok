# v116 — Left navigation rail correction

The profile icon navigation rail now sits to the LEFT of the profile card; the user-circle remains to its RIGHT. The previous v114 CSS placed the rail in the third grid column by mistake. This release changes the final placement CSS to use rail/card/circle in columns 1/2/3, updates the CSS query string and service worker cache version. Profile content, media selection, and D1 data are unchanged.

Deploy with `npx wrangler deploy`. No migration.
