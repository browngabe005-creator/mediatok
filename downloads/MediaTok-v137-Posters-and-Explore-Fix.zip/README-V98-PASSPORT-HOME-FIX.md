# MediaTok v98 — Passport Home UI Repair

This release repairs the Passport/Collection homepage UI after the previous layout update.

## What changed
- Rebuilt the Passport home markup inline in the main app renderer so the homepage content always renders instead of collapsing to an empty canvas.
- Kept the Passport-style home features from the reference:
  - left category filter list
  - large featured poster + recommendation copy
  - “made from your passport” cards
  - “what they've been into / your circle” activity row
  - “people who get you” row
  - right-side “your circle” rail
- Removed the visible scrollbar line across the Passport home experience, including the page/body scrollbar and Passport rails/tracks.
- Tightened the home grid so the main content stays visible and the right-side circle rail stays narrow.
- Limited the home circle rail to 5 visible people to better match the reference.

## Files changed
- `public/index.html`
- `public/site-layouts-v94.js`
- `public/passport-v95.css`

## Deployment
Deploy the project exactly the same way as before.

## Database
No D1 migration is required.
