# MediaTok v115 — Search in Choose Media

- A title-search field now appears in the profile's Choose Media dialog for Movies, TV & Anime, Books, and Next Up.
- Results filter instantly against logged titles in that section. No API calls are made while typing.
- Search query persists while selecting or deselecting covers, and the selection save behavior is unchanged.
- A match count and no-results message are displayed.
- Styling ensures filtered covers actually disappear in grids using explicit display rules.

No D1 migration. Deploy with `npx wrangler deploy` from the extracted project folder.
