# MediaTok v137 — poster recovery and scrolling

Changes:
- Movie artwork uses the dedicated cover endpoint first. Empty catalog responses no longer prevent independent recovery.
- Wikipedia film queries request poster thumbnails with pilicense=any; the previous default excluded non-free movie posters. Title matching remains required.
- Missing posters in paginated cards and modals now participate in shared, throttled lazy recovery. Newly inserted cards and scrolling trigger checks.
- The transparent Nova header stays in normal document flow and scrolls away instead of overlapping page content.
- Service worker cache version updated. Deploy the Worker and public assets together using the existing deployment process.

Validation:
- node tests/v137-artwork.mjs
- python tests/v137-browser.py (Playwright and /usr/bin/chromium)
- node tests/v135-film-fallback.mjs
- Worker and catalog JavaScript syntax checks

Browser checks cover 1440px and 390px layouts, Explore posters, appended cards, modal/profile posters, empty lookup fallback and header scrolling. Provider responses and image bytes are mocked in these tests. Live upstream image availability could not be checked from the restricted execution environment; posters still depend on external providers being reachable. No live deployment was performed.
