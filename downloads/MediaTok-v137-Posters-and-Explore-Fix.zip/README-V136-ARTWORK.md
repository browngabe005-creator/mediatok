# MediaTok v136 — film artwork recovery

- The screen titles were present but curated film artwork was empty.
- Cover-only endpoint now tries TMDB (if configured), Wikipedia page images (key-free), and iTunes, with title checks.
- Cover cache namespace bumped to avoid stale empty responses.
- API collection window increased to 4.1 seconds to allow fallback providers to return.
- Explore heading spacing adjusted for Nova sticky header.
- No database changes. Live upstream availability must be tested after deployment.
