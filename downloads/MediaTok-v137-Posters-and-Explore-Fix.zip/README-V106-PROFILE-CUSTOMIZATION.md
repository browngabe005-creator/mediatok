# MediaTok v106 — Customizable Collection Profile

- Corrected the Future/Collection profile groupings to **Movies & TV**, **Books** (manga, manhwa, manhua, comics, novels, light novels, webnovels and visual novels), and **Anime**. No Games panel is rendered on this profile style. This does not delete game entries.
- Added per-section **choose media** controls: owners can select or clear poster display for Movies & TV, Books, Anime, and Next Up without changing their library.
- Uses `profile_visual_overrides` with the `selection:<section>` slot for server-stored section-specific poster choices. These are visible on public profiles.
- Section order is still customizable through Arrange sections; the backend now validates the three updated section names.
- Added a dedicated CSS file to keep poster grids and category spacing consistent.
- Updated the service-worker cache to load the new CSS.

## Notes
Migration `0015_profile_visual_overrides.sql` must already exist in D1. No additional migration is required. This release hasn't been verified against the live Cloudflare database or an authenticated end-to-end browser session. Existing legacy section orders containing Games are normalized in the browser to the new three visible groups.
