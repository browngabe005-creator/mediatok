# MediaTok v119 — Your Circle data fix

The v118 fix corrected the rail's CSS but not its data source. The profile was requesting **followers only**, although Your Circle is intended to show accounts the profile owner follows. This release:

- Requests `/api/profile/:username/following` first, then falls back to followers.
- Shows avatars, usernames, and links immediately before calculating optional shared-media percentages.
- Handles API errors and empty lists visibly, with Retry and Meet People actions.
- Styles circle anchor elements (rather than only `button` elements), fixing the remaining avatar display mismatch.
- Maintains fixed left-edge navigation, far-right circle placement, and existing media customization.
- Updates the CSS query and service worker cache to v119.

No D1 migrations. Changes limited to `public/index.html`, `public/profile-edges-v117.css`, and `public/service-worker.js`.

Validation: JavaScript syntax and offline-search test. Live authenticated follow relationships remain unverified.
