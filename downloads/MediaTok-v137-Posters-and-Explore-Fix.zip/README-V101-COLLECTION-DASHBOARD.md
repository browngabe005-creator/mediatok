# MediaTok v101 — Collection dashboard

- The selected Collection UI now displays a black dashboard modeled on the supplied media-collection reference: identity, collection statistics, category tabs, filter/search/sort, and a responsive poster grid.
- Movies and TV are together; anime, manga, manhwa, manhua, novels, light novels, webnovels, comics, and visual novels are together in Books; games stay separate. Music entries are preserved in the database and can be accessed from the Other tab, rather than deleted.
- The rounded profile display's right-side sections now consolidate into Movies & TV, Books, and Games. Editing their order remains available; its API now accepts the three visible groups. Existing six-item saved preferences are migrated logically at render-time without rewriting the existing data.
- Removed user-visible mentions of “passport” from the homepage headline and changed the style picker to "Collection Style". Internal filenames and identifiers retain historical names for compatibility.
- Existing media logs, imports, and search endpoints were not changed. No new D1 migration is added. For profile section ordering, existing migration 0015 must have been applied.
- JavaScript syntax checks passed. The old v92 fixture test fails because it hardcodes the superseded six-section grouping.
- Not tested against a live authenticated deployed account.
