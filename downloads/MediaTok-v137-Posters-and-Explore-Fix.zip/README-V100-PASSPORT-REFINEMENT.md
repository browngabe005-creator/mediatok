# MediaTok v100 — Passport refinement

- Removed filled backgrounds from the Passport homepage and Future profile community rails.
- Suppressed visible scrollbars while retaining scrolling.
- Simplified the initial app loader to a plain dark background, the existing animated media cards, and “MediaTok loading.”
- Matched the Future/Passport profile columns more closely to the supplied reference while preserving profile imagery, progress, covers, actions and other layouts.
- Added profile-owner section arrangement controls (Arrange sections) to reorder movies & TV, music, books, anime, games and visual novels. Save is persisted in the existing profile_visual_overrides D1 table and visible on public profiles.
- The existing sidebar icon customization, cover customization, profile editing, My Stars editing and statuses remain intact.
- Updated service worker cache identifier to v100.

## Deployment
Deploy the Worker and static assets together. Ensure existing migration `0015_profile_visual_overrides.sql` is applied for the new server-persisted order editing to work. No new D1 migration file was created.

## Limitations
This release implements section ordering, not arbitrary freeform pixel-position dragging or rearrangement of My Stars and Next Up. Full profile parity with the reference still needs detailed visual testing against actual logged-in profile content on the live deployment.
