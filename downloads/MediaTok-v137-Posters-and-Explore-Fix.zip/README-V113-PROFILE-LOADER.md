# MediaTok v113 — profile and loading corrections

- Initial full-screen loader hides the standard site header and bottom navigation. The animation and MediaTok loading label remain.
- Future/Collection profile header replaces `now watching` with entry-rank badges (Normie, Consumer, Enthusiast, Elitist), plus staff badge when applicable.
- Removes the Arrange sections control and fixes overview category order to Movies, TV & Anime above Books.
- Adds MediaTok logo at the top of profile navigation and increases desktop spacing between the profile and right-side circle rail.
- Preserves existing Choose Media, edit profile, import, and cover controls.
- Versioned stylesheet and service-worker registration to help invalidate stale assets.
- No database migration.

Note: only static syntax/asset checks were run; live Cloudflare UI and D1 responses are not validated.
