from pathlib import Path
from urllib.parse import urlparse
from playwright.sync_api import sync_playwright
import json
P=Path(__file__).resolve().parents[1]/'public'
SVG='<svg xmlns="http://www.w3.org/2000/svg" width="200" height="300"><rect width="200" height="300" fill="purple"/></svg>'
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for width in [1440,390]:
  page=b.new_page(viewport={'width':width,'height':900},service_workers='block')
  errors=[];requests=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  def route(r):
   u=urlparse(r.request.url)
   if u.path.startswith('/api/'):
    requests.append(u.path)
    data={'results':[],'logs':[],'users':[],'notifications':[]}
    if u.path=='/api/feed': data=[]
    elif u.path=='/api/search/cover': data={'cover':'https://upload.wikimedia.org/test.jpg','alternates':[]}
    elif u.path.endswith('/cover'):data={'cover':'','alternates':[]}
    r.fulfill(json=data)
   elif u.hostname=='upload.wikimedia.org':r.fulfill(body=SVG,content_type='image/svg+xml')
   elif u.hostname=='test.local':
    f=P/(u.path.lstrip('/') or 'index.html')
    if f.is_file():r.fulfill(path=str(f))
    else:r.fulfill(status=404)
   else:r.fulfill(body='',content_type='application/javascript')
  page.route('**/*',route)
  page.goto('http://test.local',wait_until='domcontentloaded')
  page.wait_for_timeout(500)
  page.evaluate("state.feed=[];state.me=null;state.view='discover';state.type='film';state.search='';state.results=[];document.querySelector('#app').innerHTML=mtNovaDiscoverPage();")
  page.locator('#searchResults').scroll_into_view_if_needed()
  page.wait_for_function("[...document.querySelectorAll('#searchResults img')].some(i=>i.naturalWidth>0)")
  assert page.locator('#searchResults img').count()>0
  assert page.evaluate("document.querySelector('.nova-topbar').getBoundingClientRect().bottom")<0
  assert page.evaluate("getComputedStyle(document.querySelector('.nova-topbar')).position")=='relative'
  # A paginated card outside #searchResults must hydrate without an explicit caller.
  page.evaluate("document.querySelector('#app').insertAdjacentHTML('beforeend','<div id=late>'+mediaPoster({title:'Late Movie'},'film')+'</div>');document.querySelector('#late').scrollIntoView()")
  page.wait_for_timeout(1500)
  page.locator('#late').scroll_into_view_if_needed()
  page.wait_for_function("document.querySelector('#late img')?.naturalWidth>0",timeout=5000)
  page.evaluate("document.querySelector('#modalRoot').innerHTML='<div id=modalTest style=\"position:fixed;top:0;width:120px;height:180px\">'+mediaPoster({title:'Modal Movie'},'film')+'</div>'")
  page.wait_for_function("document.querySelector('#modalTest img')?.naturalWidth>0")
  page.evaluate("document.querySelector('#modalRoot').innerHTML='<div id=profileTest style=\"position:fixed;top:0;width:120px;height:180px\">'+pfPoster({title:'Profile Movie',mediaType:'film',status:'Completed'})+'</div>';hydrateProfileCovers(document.querySelector('#modalRoot'))")
  page.wait_for_function("document.querySelector('#profileTest img')?.naturalWidth>0")
  # Empty catalog response still reaches the independent endpoint for other media.
  page.evaluate("window.coverCheck=coverLookup('Example TV','tv')")
  assert page.evaluate("window.coverCheck")['cover'].endswith('test.jpg')
  assert not errors,errors
  print(f'PASS {width}px: Explore posters, header scroll, appended poster, empty-route fallback; no JS errors')
  page.close()
 b.close()
