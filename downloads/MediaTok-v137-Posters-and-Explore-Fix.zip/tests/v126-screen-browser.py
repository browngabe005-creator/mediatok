"""Browser check for the new movie/TV directory plus Nova category switch."""
from pathlib import Path
import re
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]/'public'
fixture=(root.parent/'tests/v125-ui-browser.py').read_text()
mock=fixture.split("mock=r'''",1)[1].split("'''",1)[0]
js=(root/'default-nova-v125.js').read_text()
html=(root/'index.html').read_text()
block=html[html.index('let screenBrowseOffset='):html.index('function discoverPage(){')]
setup=mock+'''
var app=document.getElementById('app');
var api=async url=>({source:'TMDB',results:[{title:'A Film',mediaType:'film',cover:'https://image.tmdb.org/t/p/w500/poster.jpg',year:'2024'}],nextOffset:20,hasMore:true,totalApprox:4500});
var $=q=>document.querySelector(q);
var mediaPoster=(r,t)=>`<img class="cover" src="${r.cover}" alt="${r.title}">`;
var openSiteMediaDetails=(t,n)=>{window.opened=[t,n]};
var renderResults=()=>'';
var mtNovaMosaic=()=>'<button class="nova-mosaic-card">Mosaic</button>';
var mtNovaShell=(content)=>content;
var mtNovaDiscoverPageMock=()=>{};
'''
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-web-security'])
 for width in (1760,960,390):
  page=browser.new_page(viewport={'width':width,'height':900})
  page.set_content('<!doctype html><html data-site-skin="default"><head><meta name="viewport" content="width=device-width,initial-scale=1"></head><body><div id="app"></div></body></html>')
  page.add_style_tag(content=(root/'default-nova-v124.css').read_text()+'\n'+(root/'default-nova-v125.css').read_text())
  page.add_script_tag(content=setup)
  page.add_script_tag(content=js)
  page.add_script_tag(content=block)
  page.evaluate("state.view='filmstv';state.type='film';state.search='';document.getElementById('app').innerHTML=mtNovaDiscoverPage()")
  assert page.locator('.nova-screen-directory').count()==1
  page.evaluate('browseMoreScreenTitles(true)')
  page.wait_for_function('document.querySelectorAll(".mt-screen-title").length===1')
  assert '4,500' in page.locator('#mt-screen-browse-status').inner_text()
  page.locator('.mt-screen-title').click()
  assert page.evaluate('window.opened')==['film','A Film']
  assert page.evaluate('document.documentElement.scrollWidth <= innerWidth + 3'),width
  print('PASS screen browse',width)
  page.close()
 browser.close()
