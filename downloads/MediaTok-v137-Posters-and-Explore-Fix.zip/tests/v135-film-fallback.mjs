import assert from 'node:assert/strict';
import { catalogRoute } from '../src/catalog-v41.js';
globalThis.fetch=async()=>{throw new Error('Simulated upstream outage')};
for(const [url,expected] of [
 ['https://mediatok.org/api/films/browse?offset=0','Star Wars'],
 ['https://mediatok.org/api/search/media?type=film&q=Star%20Wars','Star Wars'],
 ['https://mediatok.org/api/films/browse?q=Star%20Wars','Star Wars']
]) {
 const response=await catalogRoute(new Request(url),{},{});
 assert.equal(response.status,200,url);
 const body=await response.json();
 assert.ok(Array.isArray(body.results)&&body.results.some(x=>x.title.includes(expected)),JSON.stringify({url,body}).slice(0,500));
 console.log('PASS',new URL(url).pathname,body.results.length);
}
