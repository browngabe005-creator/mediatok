import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const layout=fs.readFileSync(new URL('../public/site-layouts-v94.js',import.meta.url),'utf8');
const exp=fs.readFileSync(new URL('../public/passport-v95.js',import.meta.url),'utf8');
const css=fs.readFileSync(new URL('../public/passport-v95.css',import.meta.url),'utf8');
test('Passport home matches reference structure',()=>{
  for(const token of ['ppx-top-stage','ppx-media-tabs','ppPassportMadeForYou','ppx-activity-track','ppPassportPeopleHome']) assert.ok(layout.includes(token),token);
  for(const token of ['keeps showing up nearby','nothing in common. except this']) assert.ok(exp.includes(token),token);
  assert.ok(layout.includes('users.slice(0,6)'), 'users.slice(0,6)');
});
test('Passport rails hide painted scrollbars',()=>{assert.ok(css.includes('scrollbar-width:none!important'));assert.ok(css.includes('::-webkit-scrollbar{display:none!important'));});
