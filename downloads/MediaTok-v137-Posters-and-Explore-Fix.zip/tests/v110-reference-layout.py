from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
css=(root/'public/profile-reference-v110.css').read_text()
img='data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="300" height="450"><rect width="300" height="450" fill="%233d2744"/></svg>'
poster=lambda : f'<div class="mt-ref-poster-slot"><button class="mt-ref-poster"><img class="mt-ref-cover-img" src="{img}"></button></div>'
cat=lambda : '<section class="mt-ref-future-category"><div class="mt-ref-future-covers"><div class="mt-ref-grid mt-ref-future-cgrid">'+poster()*8+'</div></div><button class="mt-ref-future-category-link">movies &amp; tv 506</button></section>'
markup='<div class="mt-layout-future"><div class="mt-ref-passport-shell"><nav class="mt-ref-future-rail">✦</nav><main class="mt-ref-passport-card"><header class="mt-ref-future-heading"><div class="mt-ref-future-id"><div class="mt-ref-future-avatar">★</div><div><h1>alice</h1><p>@iloveyoualice</p><span class="mt-ref-future-watching">now watching</span></div></div><div class="mt-ref-future-head-actions"><button class="mt-ref-future-share">share</button></div></header><p class="mt-ref-future-bio">discord.gg/mangatok</p><div class="mt-ref-future-columns"><div class="mt-ref-future-left"><section class="mt-ref-future-stars"><div class="mt-ref-future-star-grid">'+poster()*5+'</div><div class="mt-ref-future-sectiontitle">my stars</div></section><section class="mt-ref-future-next"><div class="mt-ref-future-nextrow">'+poster()*4+'</div><div class="mt-ref-future-sectiontitle">next up</div></section></div><div class="mt-ref-future-collection">'+cat()*3+'</div></div></main><aside class="mt-ref-future-circle"><h2>your circle</h2></aside></div></div>'
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 for width in (1760,1024,390):
  page=browser.new_page(viewport={'width':width,'height':920})
  page.set_content('<style>body{margin:0;background:black}.mt-ref-poster-slot{position:relative}.mt-ref-poster-slot img{width:100%;height:100%;object-fit:cover}.mt-ref-poster{border:0;padding:0;background:#38333c}'+css+'</style>'+markup)
  geometry=page.evaluate('''() => {let a=document.querySelector('.mt-ref-future-star-grid').children[0].getBoundingClientRect(), b=document.querySelector('.mt-ref-future-star-grid').children[1].getBoundingClientRect(), shell=document.querySelector('.mt-ref-passport-card').getBoundingClientRect();return {largeWidth:a.width,smallWidth:b.width,cardWidth:shell.width,documentWidth:document.documentElement.scrollWidth,viewWidth:innerWidth}}''')
  print(width,geometry)
  assert geometry['documentWidth'] <= geometry['viewWidth']+2
  assert geometry['largeWidth'] > geometry['smallWidth']*1.9
  page.close()
 browser.close()
print('v110 layout geometry passed')
