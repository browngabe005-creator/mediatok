from playwright.sync_api import sync_playwright
from pathlib import Path
import json
P=Path(__file__).resolve().parents[1]/'public'
CSS='\n'.join((P/f).read_text() for f in ('default-nova-v124.css','default-nova-v125.css','default-nova-v127.css'))
JS=(P/'default-nova-v125.js').read_text()
stubs=r'''
window.state={view:'discover',type:'anime',search:'',results:[],feed:[],profileTab:'overview',unreadNotifications:0,me:{name:'Alice',globalName:'Alice'}};
window.TYPES={anime:{label:'Anime'},film:{label:'Films'},tv:{label:'TV'},manga:{label:'Manga'},novel:{label:'Novels'},'light-novel':{label:'Light Novels'},webnovel:{label:'Webnovels'},game:{label:'Video games'},'visual-novel':{label:'Visual novels'},comic:{label:'Comics'},all:{label:'All'}};
window.NICHE_PICKS={anime:[['Naruto','anime'],['Monster','anime'],['Serial Experiments Lain','anime']],tv:[['The Sopranos','tv'],['Twin Peaks','tv'],['Severance','tv']],film:[['Perfect Blue','film'],['Stalker','film'],['Persona','film']],manga:[['Berserk','manga'],['Solanin','manga'],['Monster','manga']],novel:[['White Nights','novel'],['Dune','novel'],['1984','novel']],game:[['Outer Wilds','game'],['Disco Elysium','game'],['SOMA','game']]};
window.esc=s=>String(s??'').replaceAll('&','&amp;').replaceAll('"','&quot;').replaceAll('<','&lt;');
window.ico=s=>'<svg class="ic" viewBox="0 0 24 24"><circle cx="12" cy="12" r="8" fill="none" stroke="currentColor" /></svg>';
window.userLink=s=>'/user/'+s;
window.avatar=(u,n)=>'<img class="avatar" src="" alt="Avatar" />';
window.knownArtwork=(title,type)=>'data:image/svg+xml,'+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="100" height="150"><rect width="100" height="150" fill="'+({anime:'#aa5cce',tv:'#4a7fab',film:'#4a7fab',manga:'#bd7376',game:'#459c9e'}[type]||'#886699')+'"/></svg>');
window.catalogDisplaySrc=s=>s;window.sharedCoverForTitle=async(title,type)=>knownArtwork(title,type);
window.homepageFeaturedPicks=()=>[];window.pickCards=()=>'<div class="niche-grid"></div>';window.renderMemberResults=()=>'';window.goView=v=>{window.lastNav=v};window.login=()=>{};window.mtOwnProfile=()=>false;window.mtNovaSubpage=()=>'';
window.mtMusicPanel=()=>'';window.mtCurrentItem=()=>'';
'''
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for width,height in [(1790,900),(1440,900),(1024,850),(740,800),(390,844)]:
  page=b.new_page(viewport={'width':width,'height':height}, device_scale_factor=1)
  page.set_content('<html data-site-skin="default"><head><style>'+CSS+'</style></head><body><div id="app"></div></body></html>')
  page.add_script_tag(content=stubs)
  page.add_script_tag(content=JS)
  page.evaluate("document.querySelector('#app').innerHTML=window.mtNovaDiscoverPage()")
  # Check header + mosaic + images
  metrics=page.evaluate('''() => {
   const r=s=>{let e=document.querySelector(s); if(!e)return null;let x=e.getBoundingClientRect();return {x:x.x,y:x.y,w:x.width,h:x.height,midY:x.top+x.height/2}};
   return {header:r('.nova-topbar'),title:r('.nova-top-intro'),search:r('.nova-search'),actions:r('.nova-top-actions'),brandImg:r('.nova-brand-mark img'),tiles:[...document.querySelectorAll('.nova-mosaic-card')].map(el=>({w:el.getBoundingClientRect().width,posters:el.querySelectorAll('.nova-mosaic-poster').length})),scrollWidth:document.documentElement.scrollWidth,clientWidth:document.documentElement.clientWidth};
  }''')
  print(width, json.dumps(metrics, separators=(',',':')))
  if width==1790: print('imgs',page.evaluate("[...document.querySelectorAll('.nova-mosaic-poster img')].slice(0,4).map(i=>({src:i.src.slice(0,45),complete:i.complete,natural:i.naturalWidth}))"))
  if width == 1790:
   page.screenshot(path=str(P.parent/'v127-explore-fixture.png'),full_page=False)
  assert len(metrics['tiles'])==4 and all(x['posters']==3 for x in metrics['tiles'])
  if width==1790:
   page.locator('.nova-mosaic-film').click()
   assert page.evaluate('window.state.type') == 'film' and page.evaluate('window.lastNav') == 'discover'
   # A missed initial artwork match should fill without replacing its card.
   page.evaluate("document.querySelector('.nova-mosaic-manga .nova-mosaic-poster img')?.remove()")
   page.evaluate("window.mtNovaHydrateMosaic()")
   page.wait_for_timeout(200)
   assert page.locator('.nova-mosaic-manga .nova-mosaic-poster img').count() == 3
   print('mosaic navigation and cover hydration OK')
   page.evaluate("window.state.view='home';document.querySelector('#app').innerHTML=window.mtNovaShell('<div class=\\\"nova-home\\\"><h1>Homepage remains unchanged</h1></div>')")
   home=page.evaluate('''() => [document.querySelector('.nova-top-intro').getBoundingClientRect().y,document.querySelector('.nova-search').getBoundingClientRect().y]''')
   print('home-top',home)
  assert metrics['scrollWidth']<=metrics['clientWidth']+1, 'overflow at '+str(width)
  if width>=800:
   assert abs(metrics['title']['midY']-metrics['search']['midY'])<2
   assert abs(metrics['actions']['midY']-metrics['search']['midY'])<2
  page.close()
 b.close()
