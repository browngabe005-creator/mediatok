"""Offline browser smoke checks for Default Nova v125; mocked user records, no network calls."""
from pathlib import Path
from playwright.sync_api import sync_playwright
from urllib.parse import quote
import json
root=Path(__file__).resolve().parents[1]/'public'
base=(root/'default-nova-v124.css').read_text()
extra=(root/'default-nova-v125.css').read_text()
js=(root/'default-nova-v125.js').read_text()
mock=r'''
var state={view:'home',type:'all',me:{id:1,name:'alice',globalName:'Alice'},search:'',results:[],memberResults:[],feed:[],profileTab:'overview',profileStatus:'All',profileSort:'recent'};
var TYPES={all:{label:'All media'},anime:{label:'Anime'},manga:{label:'Manga'},film:{label:'Films'},tv:{label:'TV shows'},novel:{label:'Novels'},'light-novel':{label:'Light novels'},webnovel:{label:'Web novels'},comic:{label:'Comics'},game:{label:'Games'},'visual-novel':{label:'Visual novels'}};
var esc=(x)=>String(x||'').replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
var ico=(n)=>`<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="7"/></svg>`;
var avatar=(u,n)=>`<span class="avatar" style="display:block;width:${n}px;height:${n}px;background:linear-gradient(120deg,#9a8cff,#47b8aa);border-radius:50%"></span>`;
var userLink=(s)=>'/u/'+s;
var catalogCoverSrc=(x)=>x;
var catalogDisplaySrc=(x)=>x;
var pickCards=()=>'<div>sample covers</div>';
var renderResults=()=>'<div>Media results</div>';
var renderMemberResults=()=>'';
var homepageFeaturedPicks=()=>[{title:'Anime test',mediaType:'anime',cover:'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="120" height="180"%3E%3Crect width="120" height="180" fill="%237f5fdf"/%3E%3C/svg%3E'},{title:'Movie test',mediaType:'film',cover:'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="120" height="180"%3E%3Crect width="120" height="180" fill="%2377a0bd"/%3E%3C/svg%3E'},{title:'Reading test',mediaType:'manga',cover:'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="120" height="180"%3E%3Crect width="120" height="180" fill="%23c4869e"/%3E%3C/svg%3E'},{title:'Game test',mediaType:'game',cover:'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="120" height="180"%3E%3Crect width="120" height="180" fill="%234bb2a6"/%3E%3C/svg%3E'}];
var pfPoster=(l)=>`<article class="pf-poster"><div class="pf-frame"><span class="pf-img" style="display:block;width:100%;height:100%;background:linear-gradient(${l.n*30}deg,#383f75,#cf87a3)"></span></div><b class="pf-title">${esc(l.title)}</b><small class="pf-sub">${esc(l.status)}</small></article>`;
var mtCurrentItem=(l)=>`<div class="mt-current-item"><span class="mt-current-poster" style="background:#847baf"></span><span class="mt-current-copy"><strong>${esc(l.title)}</strong><small>${esc(l.status)}</small></span></div>`;
var isPlanning=(l)=>l.status==='Planning';
var mtOwnProfile=()=>true;
var parseFavs=()=>[];
var rnum=(l)=>Number.isFinite(l.rating)?l.rating:null;
var profileAvatar=(u,n)=>avatar(u,n);
var safeAccent=(x)=>'#a99aff';
var bannerStyle=(u)=>'background:radial-gradient(circle at 70% 20%,#4e3d80,transparent 60%),#111322';
var mtMusicPanel=()=>'<section class="nova-profile-section"><h2>Music</h2><p>Artists and favorite tracks</p></section>';
var socialHref=()=>null;
var profileResetFooter=()=>'';
var goView=(view)=>{state.view=view; document.getElementById('app').innerHTML=mtNovaDiscoverPage();};
var setProfileTab=(tab)=>{state.profileTab=tab;document.getElementById('app').innerHTML=mtNovaShell(mtNovaProfilePage(window.mockProfile),false,true);};
state.profileLogs=Array.from({length:24},(_,n)=>({n,title:'Saved title '+(n+1),mediaKey:'key'+n,mediaType:['anime','manga','film','tv','novel','light-novel','webnovel','game','visual-novel','comic'][n%10],rating:(n%10)+1,status:n<4?'Planning':n<7?'In progress':'Completed',updatedAt:n+1}));
window.mockProfile={name:'alice',globalName:'Alice',bio:'Stories, everything, all in one place.',stats:{total:127},role:'admin',followers:89,socials:{}};
'''
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-web-security'])
    for w,h in [(1760,900),(1440,900),(1024,800),(390,844)]:
        page=browser.new_page(viewport={'width':w,'height':h},device_scale_factor=1)
        page.set_content('<!DOCTYPE html><html data-site-skin="default"><head></head><body style="margin:0"><div id="app"></div></body></html>')
        page.add_style_tag(content=base)
        page.add_style_tag(content=extra)
        page.add_script_tag(content=mock)
        page.add_script_tag(content=js)
        page.evaluate("state.view='profile';document.getElementById('app').innerHTML=mtNovaShell(mtNovaProfilePage(window.mockProfile),false,true)")
        page.wait_for_timeout(850)
        prof=page.evaluate('''() => ({height:document.documentElement.scrollHeight,width:document.documentElement.scrollWidth,viewportHeight:innerHeight,top:document.querySelector('.nova-profile-cover').getBoundingClientRect().top,tab:document.querySelector('.nova-profile-tabbar').getBoundingClientRect().top,bodyBottom:document.querySelector('.nova-profile-body').getBoundingClientRect().bottom,tabs:[...document.querySelectorAll('.nova-profile-medium-picker option')].map(x=>x.value),favoriteCount:document.querySelectorAll('.nova-favorites-grid .pf-poster').length})''')
        assert prof['width']<=w+1, (w,prof)
        if w>=1300: assert prof['height']<=h+1, ('desktop profile overview should fit',w,prof)
        assert 'webnovel' in prof['tabs'] and 'visual-novel' in prof['tabs'] and 'game' in prof['tabs'], prof
        print(f'PROFILE {w}x{h}: {prof}')
        if w==1760:
            print('CONTENT COMPUTED',page.evaluate('''() => {let e=document.querySelector('.nova-content');let c=getComputedStyle(e);return {padTop:c.paddingTop,padBottom:c.paddingBottom,height:c.height,box:c.boxSizing,marginBottom:c.marginBottom}}'''))
            print('OVERFLOW ELEMENTS',page.evaluate('''() => [...document.querySelectorAll('body *')].map(e=>({cls:e.className?.baseVal||e.className||e.tagName,btm:Math.round(e.getBoundingClientRect().bottom),top:Math.round(e.getBoundingClientRect().top)})).filter(x=>x.btm>900).slice(0,12)'''))
            page.screenshot(path='/mnt/data/MediaTok-v125-profile-preview.png')
        # discover context
        page.evaluate("state.view='discover';document.getElementById('app').innerHTML=mtNovaDiscoverPage()")
        page.wait_for_timeout(850)
        disc=page.evaluate('''() => ({width:document.documentElement.scrollWidth,cards:document.querySelectorAll('.nova-mosaic-card').length,images:document.querySelectorAll('.nova-mosaic-image').length,filterCount:document.querySelectorAll('.nova-discover-toolbar button').length})''')
        assert disc['cards']==4 and disc['images']>=3 and disc['filterCount']>=10,(w,disc)
        assert disc['width']<=w+1,(w,disc)
        print(f'DISCOVER {w}x{h}: {disc}')
        page.locator('.nova-mosaic-card').last.click()
        assert page.evaluate('state.type')=='game' and page.evaluate('state.view')=='discover', 'game card should navigate to game catalog'
        page.evaluate("state.view='profile';state.profileTab='overview';document.getElementById('app').innerHTML=mtNovaShell(mtNovaProfilePage(window.mockProfile),false,true)")
        page.locator('.nova-profile-medium-picker select').select_option('visual-novel')
        assert page.evaluate('state.profileTab')=='visual-novel', 'visual novel profile filter should work'
        assert page.locator('.nova-profile-section').count()>0, 'selected media panel should render'
        assert page.get_by_text('Install app').count()==0
        if w==1760:page.screenshot(path='/mnt/data/MediaTok-v125-explore-preview.png')
        page.close()
    browser.close()
