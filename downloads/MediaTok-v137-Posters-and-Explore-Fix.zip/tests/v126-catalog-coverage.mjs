import assert from 'node:assert/strict';
import {catalogRoute} from '../src/catalog-v41.js';
const original=globalThis.fetch;
const seen=[];
const response=x=>new Response(JSON.stringify(x),{headers:{'Content-Type':'application/json'}});
globalThis.fetch=async url=>{
 const u=new URL(String(url));seen.push(u);
 if(u.hostname==='api.themoviedb.org'){
  const kind=u.pathname.split('/').pop(),page=Number(u.searchParams.get('page')||1);
  assert.equal(u.searchParams.get('api_key'),'fake-secret');
  return response({page,total_pages:300,total_results:6000,results:[{id:page,poster_path:'/poster.jpg',title:kind==='movie'?'A Sample Movie':undefined,name:kind==='tv'?'A Sample Show':undefined,release_date:'2024-01-01',first_air_date:'2024-01-01'}]});
 }
 if(u.hostname==='itunes.apple.com')return response({results:[]});
 if(u.hostname==='api.tvmaze.com')return response(u.pathname==='/shows'?Array.from({length:250},(_,i)=>({id:i+1,name:'Show '+i,image:{medium:'https://static.tvmaze.com/image.jpg'}})):[{show:{id:3,name:'A Sample Show',image:{medium:'https://static.tvmaze.com/image.jpg'}}}]);
 return response({data:{Page:{media:[]}}});
};
const env={TMDB_API_KEY:'fake-secret'};
async function request(path,envObject=env){const res=await catalogRoute(new Request('https://mediatok.org'+path),envObject,null);assert.equal(res.status,200);return await res.json();}
const film=await request('/api/films/browse?offset=20');
assert.equal(film.results[0].title,'A Sample Movie');assert.match(film.results[0].cover,/image.tmdb.org/);assert.equal(film.nextOffset,40);assert.equal(film.totalApprox,6000);assert(film.hasMore);
const tv=await request('/api/tv/browse?offset=0');assert.equal(tv.results[0].title,'A Sample Show');assert.equal(tv.results[0].mediaType,'tv');
const fallback=await request('/api/tv/browse?offset=40',{});assert.equal(fallback.results.length,40);assert.equal(fallback.results[0].title,'Show 40');assert.equal(fallback.nextOffset,80);
const search=await request('/api/search/media?type=film&q=Sample');assert.equal(search.results[0].title,'A Sample Movie');
const withoutKey=await request('/api/films/browse',{});assert.equal(withoutKey.providerStatus,'offline');assert.match(withoutKey.message,/TMDB_API_KEY/);
console.log('PASS v126: TMDB movie/TV pagination; secure key; TVmaze 250-show index paging; no-key guidance; film search');
globalThis.fetch=original;
