"""Standalone Chromium regression test for Nova recommendation grid / legacy loader collision.
Run: python3 tests/nova-v123-browser.py
Requires playwright and Chromium; works with a mock homepage without network access.
"""
import base64
import json
import re
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT = Path(__file__).resolve().parents[1] / 'public'
HTML = (ROOT/'index.html').read_text()
CSS = (ROOT/'default-nova-v123.css').read_text()
JS = (ROOT/'default-nova-v123.js').read_text()

def extract(start, end):
    i = HTML.index(start)
    return HTML[i:HTML.index(end, i)]

legacy_loader = extract('async function loadFeatured(force=false){', '\nfunction quickAddFeatured(')
artwork_refresh = extract('function refreshHomepageFromKnownArtwork(){', '\nfunction saveVerifiedArtwork(')

def svg_data(color, label):
    svg = f'<svg xmlns="http://www.w3.org/2000/svg" width="300" height="450"><rect width="300" height="450" fill="{color}"/><circle cx="155" cy="180" r="90" fill="#ffffff30"/><text x="25" y="385" font-size="27" fill="white" font-family="Arial">{label}</text></svg>'
    return 'data:image/svg+xml;base64,' + base64.b64encode(svg.encode()).decode()

picks = [dict(title=f'Title {i+1}',type='anime',cover=svg_data(c,f'Title {i+1}')) for i,c in enumerate(['#4e6ca5','#764b8e','#9a545c','#3a7868','#a4773c','#536688','#aa3377'])]
setup = '''
window.esc=s=>String(s??'').replaceAll('&','&amp;').replaceAll('"','&quot;').replaceAll('<','&lt;');
window.ico=name=>`<svg class="ic" viewBox="0 0 24 24"><path d="M3 12L21 12"/></svg>`;
window.TYPES={anime:{label:'Anime'}};
window.catalogCoverSrc=s=>s;
window.catalogDisplaySrc=s=>s;
window.state={me:null,view:'home',feed:[],unreadNotifications:0,search:''};
window.homepageFeaturedPicks=()=>window.picks;
window.loadHomeLogStatuses=async()=>{};
window.$=selector=>document.querySelector(selector);
window.loadPickCovers=()=>{throw new Error('legacy art loader must not be used in Nova')};
window.MEDIUM_SHOWCASE_TYPES={};
'''

def card_widths(page):
    return page.evaluate('''() => [...document.querySelectorAll('#featuredMedia > .nova-cover-item')].map(el => Math.round(el.getBoundingClientRect().width))''')

with sync_playwright() as playwright:
    browser=playwright.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
    for width, minimum, expected_first_row in [(1790,110,5), (1024,95,4), (390,70,3)]:
        page=browser.new_page(viewport={'width':width, 'height':950},device_scale_factor=1)
        page.set_content('<!doctype html><html data-site-skin="default"><head><meta name="viewport" content="width=device-width,initial-scale=1"></head><body><div id="app"></div></body></html>')
        page.add_style_tag(content=CSS)
        page.add_script_tag(content=setup)
        page.evaluate('(picks) => {window.picks=picks}',picks)
        page.add_script_tag(content=JS)
        page.evaluate("document.getElementById('app').innerHTML=mtNovaShell(mtNovaHomePage())")
        before=card_widths(page)
        assert len(before)==5 and min(w for w in before if w)>=(minimum), (width,'before',before)
        # Initial load should never overwrite Nova's directly rendered cards.
        page.add_script_tag(content=legacy_loader)
        page.evaluate('loadFeatured()')
        after=card_widths(page)
        assert after==before, (width,'after loadFeatured',before,after)
        assert page.locator('#featuredMedia > .niche-grid').count()==0, (width,'nested legacy grid')
        # The artwork refresh callback should leave Nova's grid intact.
        page.add_script_tag(content=artwork_refresh)
        page.evaluate('refreshHomepageFromKnownArtwork()')
        assert card_widths(page)==after
        assert page.locator('#featuredMedia > .niche-grid').count()==0
        # Emulate artwork changing; async refresh must still restore five direct cards.
        changed=picks.copy();changed[0]={**changed[0],'cover':svg_data('#336699','Replacement')}
        page.evaluate('(picks)=>{window.picks=picks;mtNovaRefreshRecommendations()}',changed)
        assert len(card_widths(page))==5 and min(w for w in card_widths(page) if w)>=minimum
        # Even if stale JS inserts a nested .niche-grid, CSS should unnest its children.
        fallback=page.evaluate('''() => {
          const root=document.querySelector('#featuredMedia');
          root.innerHTML=`<div class="niche-grid">${Array.from({length:5},(_,i)=>`<article class="niche-card"><div class="niche-art"><img src="${window.picks[i].cover}" alt=""></div><div class="niche-info">Cover ${i}</div></article>`).join('')}</div>`;
          return [...root.querySelectorAll('.niche-card')].map(n=>Math.round(n.getBoundingClientRect().width))
        }''')
        assert len(fallback)==5 and min(w for w in fallback if w)>=minimum, (width,'fallback',fallback)
        print(f'PASS viewport={width}px direct={before}, nested-fallback={fallback}, visible-grid-columns={expected_first_row}')
        page.close()
    browser.close()
