"""Nova v124 offline browser smoke tests: library renderer + styles, filters, shell geometry."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json, re, sys
P=Path(__file__).resolve().parents[1]/'public'
html=(P/'index.html').read_text()
code=html[html.index('function mt109LibraryPage()'):html.index('async function render(){',html.index('function mt109LibraryPage()'))]
css=(P/'default-nova-v124.css').read_text()
# icon art used here is synthetic; test geometry, not online catalog images.
mock_art=lambda color: "data:image/svg+xml,"+f"%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20width='200'%20height='300'%3E%3Crect%20width='200'%20height='300'%20fill='%23{color}'/%3E%3C/svg%3E"
rows=[]
for i,(type_,name) in enumerate([('anime','Kino’s Journey'),('film','Perfect Days'),('novel','The Left Hand of Darkness'),('manga','Look Back'),('tv','Twin Peaks'),('game','Celeste'),('anime','Frieren'),('comic','Monstress'),('film','Arrival')]):
 rows.append({'title':name,'mediaType':type_,'cover':mock_art(['9e6874','8e758a','4d8496','a37747','5f6798','7c9780','80638c','5b8a87','bb9975'][i]),'status':['Completed','In progress','Planning'][i%3],'rating':i+1,'updatedAt':100-i})
setup='''
const state={me:{name:'Alice'},view:'library'};
let mt109Rows=[],mt109Category='all',mt109Request=0;
const TYPES={anime:{label:'Anime'},film:{label:'Movie'},tv:{label:'TV'},novel:{label:'Novel'},manga:{label:'Manga'},comic:{label:'Comic'},game:{label:'Game'}};
function esc(t){return String(t).replace(/[&<>\"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}[c]));}
function ico(name){return '<span class="ic">'+name+'</span>';}
function catalogDisplaySrc(v){return v;}
function goView(v){window._nav=v;}
function userLink(name){return '/'+name;}
async function api(url){ if(url.includes('/api/logs'))return window.__rows;return {user:{name:'Alice'}}; }
function openSiteMediaDetails(type,title){window._opened={type,title};}
'''
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
 for width in [1760,1024,760,390]:
  page=browser.new_page(viewport={'width':width,'height':920}, device_scale_factor=1)
  page.set_content('<!doctype html><html data-site-skin="default"><head><meta name="viewport" content="width=device-width,initial-scale=1"><style>'+css+'</style><style>body{margin:0;background:#0a0e14;color:#fff;font-family:Arial,sans-serif}</style></head><body><div class="nova-app"><aside class="nova-sidebar"></aside><div class="nova-workspace"><div class="nova-topbar">MediaTok</div><main class="nova-content" id="target"></main></div></div></body></html>')
  page.add_script_tag(content=setup+code+'\nwindow.__rows = '+json.dumps(rows)+';\ndocument.getElementById("target").innerHTML=mt109LibraryPage();\nmt109LoadLibrary();')
  page.wait_for_function('document.querySelectorAll("#mt109Grid .mt109-tile").length===9')
  assert page.locator('#novaArchiveTotal').inner_text()=='9'
  assert page.locator('#novaArchiveFinished').inner_text()=='3'
  if width==1760:
   page.locator('[data-mt109-tab="books"]').click()
   assert page.locator('#mt109Grid .mt109-tile').count()==3
   page.locator('[data-mt109-tab="all"]').click()
   page.locator('#mt109Search').fill('Celeste')
   assert page.locator('#mt109Grid .mt109-tile').count()==1
   page.locator('#mt109Search').fill('')
   page.locator('#mt109Grid .mt109-tile').first.click()
   assert page.evaluate('window._opened.title')=='Kino’s Journey'
  dims=page.evaluate('''() => ({doc:document.documentElement.scrollWidth,view:innerWidth,grid:document.querySelector('#mt109Grid').getBoundingClientRect().width,card:document.querySelector('.mt109-tile')?.getBoundingClientRect().width,cols:getComputedStyle(document.querySelector('#mt109Grid')).gridTemplateColumns})''')
  assert dims['doc'] <= dims['view']+2, ('horizontal overflow',width,dims)
  assert dims['card']>=70, ('narrow media card',width,dims)
  page.screenshot(path=str(P.parents[1]/f'v124_library_{width}.png'),full_page=(width==1760))
  print('PASS library width',width,dims)
  page.close()
 # secondary page check: statically render own wrappers using CSS against different views
 for view in ['feed','forum','lists','settings','leaderboard','discover']:
  page=browser.new_page(viewport={'width':1440,'height':900})
  page.set_content('<!doctype html><html data-site-skin="default"><head><meta name="viewport" content="width=device-width,initial-scale=1"><style>'+css+'</style></head><body><div class="nova-app"><aside class="nova-sidebar"></aside><div class="nova-workspace"><main class="nova-content" id="target"></main></div></div></body></html>')
  # add site javascript only subpage entry to avoid unrelated program initialization
  nova=(P/'default-nova-v124.js').read_text()
  if view!='discover':
   sub=nova[nova.index('window.mtNovaSubpage=function(view,inner){'):nova.index('window.mtNovaShell=')]
   page.add_script_tag(content='function ico(i){return "<span class=ic>"+i+"</span>"};function goView(v){};'+sub+f'\ndocument.querySelector("#target").innerHTML=mtNovaSubpage("{view}","<article class=card><h2>Community feature</h2><p>Real pages keep their original controls.</p></article>");')
   assert page.locator(f'.nova-space-{view}').count()==1
  else:
   # actual discover page screenshot fixture using the live template-like markup only
   page.locator('#target').evaluate('''el=>el.innerHTML=`<div class="nova-discover"><section class="nova-discover-hero"><div class="nova-discover-intro"><span class="nova-eyebrow">EXPLORE / THE CATALOG</span><h1>Anything is out there.</h1><p>Find a story.</p></div><div class="nova-discover-mosaic"><button>Animation</button><button>Films</button><button>Books</button></div><form class="nova-discover-search"><input placeholder="Search"/><button>Find</button></form></section></div>`''')
  dims=page.evaluate('''() => ({w:document.documentElement.scrollWidth,view:innerWidth})''')
  assert dims['w']<=dims['view']+2,(view,dims)
  if view in ['lists','feed','settings','discover']:
   page.screenshot(path=str(P.parents[1]/f'v124_{view}.png'))
  print('PASS page',view,dims)
  page.close()
 browser.close()
