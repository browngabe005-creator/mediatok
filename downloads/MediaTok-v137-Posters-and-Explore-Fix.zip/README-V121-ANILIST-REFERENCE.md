# MediaTok v121 — AniList Website Layout Reference

The AniList SITE setting now has a separate header, activity-first homepage, and Browse page based on the screenshots supplied. Profile layouts remain unchanged.

## Homepage
- Centered dark horizontal header and compact navigation
- Main activity column with Following / Global tabs and logged media feed
- Right-side announcement and Anime/Manga in-progress grids (user’s logs when available, existing catalog picks otherwise)

## Browse
- Search field, visible Genres, Year, Season and Format selectors
- Five-column trending, seasonal and popular poster rows with existing cover/detail behavior
- Category buttons for anime, manga, films, TV, novels and games
- Search/results use MediaTok’s existing catalog search

**Current limitation:** Genres, Year, Season, and Format are visual selectors, not provider-backed compound filters. They display an explanatory message rather than pretending to filter successfully. Fully working compound filtering requires extending the catalog search API.

## Other
- Default and Collection site styles and public profile layouts are unchanged.
- No D1 database migrations.
- Service worker cache bumped to v121.
- Run `npx wrangler deploy` from the extracted project directory.
