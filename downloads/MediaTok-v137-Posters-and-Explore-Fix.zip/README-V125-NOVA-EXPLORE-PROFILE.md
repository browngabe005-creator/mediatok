# MediaTok v125 — Nova animated Explore & compact Profile

## Scope
Changes apply to the Nova (Default) site mode and the Default profile. AniList and Collection styles, the v124 homepage, Worker API endpoints, D1 database, and existing media logs are retained.

## Explore
- Replaces the plain category tiles with 4 animated catalog cards: Anime, Movies & TV, Reading, and Video Games.
- Uses artwork already available in MediaTok's featured picks/activity feed. CSS-generated gradients, orbit, and layered artwork shapes prevent blank cards when images are unavailable. No new image service/API.
- Adds accessible navigation to all supported types: Anime, Films, TV, Manga (including manhwa/manhua), Novels, Comics, Light Novels, Webnovels, Visual Novels, and Games.
- All category controls preserve the existing media search API. Manhwa/manhua are names within the **manga** category because they are not independent D1 media types; no data migration has been performed.

## Default profile
- Overview includes Favorites (up to 5), Watchlist preview (up to 4), Currently Into (up to 3), and Collection Snapshot. Recent entries, Activity, and Music moved into separate profile tabs for a shorter overview, not deleted.
- Media-category select provides Anime, Manga, Film, TV, Novels, Light Novels, Webnovels, Comics, Video Games, and Visual Novels even if the user has no logged items in a category.
- Compact desktop layout measured to fit a 900px-high viewport at 1440px and 1760px widths in an isolated browser test, while smaller viewports scroll naturally so content stays accessible.
- Subtle profile transitions and cover hover movement. Supports `prefers-reduced-motion`.

## Removed
- Install App button from the Nova sidebar and legacy header; removed manual install prompt listeners and web-app manifest link. No stored records are deleted.

## Changed files
- `public/default-nova-v125.js` — Nova renderer update, replaces v124 JavaScript.
- `public/default-nova-v125.css` — new scoped visual overrides, loaded after the existing Nova v124 CSS.
- `public/index.html` — load the new JS/CSS, remove installation UI.
- `public/service-worker.js` — fresh cache name / updated assets.
- `tests/v125-ui-browser.py` — offline browser regression harness with sample data.

## Verification
- `node --check` for scripts and HTML inline script extraction
- `node tests/v44-offline-search.mjs`
- `python3 tests/v125-ui-browser.py` tests desktop/tablet/mobile width, browser navigation into Game discovery, select Visual Novels on profile, and avoids horizontal overflow
- Browser tests use mocked account content; live authenticated database and image CDN behavior remain to be verified after deployment.

## Deploy
Unzip and run `npx wrangler deploy` from the extracted folder. No new D1 migration. Existing database binding remains unchanged.
