# MediaTok v99 — independent Passport homepage shell

Fixes the mispositioned left-hand circle rail and blank Passport home canvas by replacing the home-only shared grid with an independent fixed navigation rail, guaranteed visible main content, and fixed right circle sidebar.

Changes: public/site-layouts-v94.js (home shell), public/index.html (new home-only stylesheet, cache-busted shell script), public/passport-home-v99.css (home-only layout, hidden scrollbar tracks), public/service-worker.js (new cache key).

Preserves original data, existing APIs, themes, alternate layouts, profiles and other pages. No D1 migrations.

Browser layout smoke tests run against actual home HTML generator at widths 1790, 1000 and 390 pixels, checking main content presence, right-rail placement, and horizontal overflow. Live deployment/authenticated functionality still needs testing.
