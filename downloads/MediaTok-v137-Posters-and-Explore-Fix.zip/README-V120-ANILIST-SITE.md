# MediaTok v120 — AniList-style site UI

## Scope
Only the site-wide **Anime / AniList** appearance setting is redesigned. Existing public profile layouts and user media remain untouched.

## Included
- AniList-style dark top navigation with media categories and account actions.
- Light browse-oriented homepage with six-cover rows for anime, manga, films and novels, recommendations, and community activity.
- Unified visual treatment for existing discovery, search, lists, forum, feed and settings routes.
- Library route kept on its self-contained loader and displayed inside the new navigation shell.
- Mobile responsive nav, focus states, reduced-motion support and a dark-theme fallback.

## Important distinctions
- This is a newly authored layout **inspired by** AniList's information architecture and measurements; it is not AniList source code or a pixel-perfect copy.
- Existing MediaTok data providers, routes, user sessions, profiles, and API responses are kept; AniList-only services are not duplicated.
- No migrations required.

## Tests
- `node --check` for new JavaScript and main inline JavaScript
- `node tests/v44-offline-search.mjs`

## Deploy
From this project folder, run `npx wrangler deploy`. No database migration is needed.
