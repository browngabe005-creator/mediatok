# v117 — Profile rail positions

Navigation is pinned to the extreme left, the profile stays centered, and Your Circle is pinned to the extreme right on wide desktop screens. This release does not change media data or editing actions.

No migration required. Deploy with `npx wrangler deploy`.
