# v102 — Arrange Collection Button Repair
- Makes the Arrange Collection dialog consistently open above the profile.
- Locks body scrolling while arranging and closes cleanly.
- Improves contrast, stacking, and clickable move controls.
- Saves the order through the existing future-visual endpoint and reports save failures, including missing migration 0015.
- No new database migration or changes to media logs.
