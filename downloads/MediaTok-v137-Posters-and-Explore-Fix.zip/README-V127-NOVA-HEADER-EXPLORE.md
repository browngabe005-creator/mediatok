# MediaTok v127 — Nova Header & Explore Artwork

This release changes **only the Default/Nova client interface**. AniList and Collection styles, the homepage hero, profile layouts, server routes, and D1 data are preserved.

## Changes

- Replaced the rounded purple "M" branding with the existing original `mt-logo.png` artwork.
- Changed the workspace header from an uneven flex row to a three-column grid. Page title, search, notifications/sign-in, and avatar now share a single vertical center.
- Made the workspace header sticky during page scrolling, addressing the cut-off search/header shown in the Explore screenshot.
- Rebuilt the four Explore-category visual stacks to use a distinct three-cover fan for Anime, Movies & TV, Reading, and Video Games.
- Each stack uses its own media types and titles from current results, community media, and its category's existing curated picks. Previously, some stacks were empty because they relied on random homepage picks of unrelated types.
- When artwork has not yet been resolved, the original shared cover lookup can progressively fill the stack. The card is never blank while waiting.
- Added soft staggered floating movement, glow, hover spread, and reduced-motion support.
- Updated the stylesheet version and service-worker cache to ensure deployment replaces cached assets.

## Tests

- JavaScript syntax checks passed.
- Browser DOM layout tested at 1790, 1440, 1024, 740, and 390px wide.
- Header title, search, and account controls had matching vertical centers on tested desktop sizes.
- Four Explore cards displayed three cover slots each with no horizontal overflow.
- Category click and progressive missing-cover hydration passed using local test fixtures.
- `tests/v44-offline-search.mjs` and `tests/v126-catalog-coverage.mjs` passed; the latter uses mocked providers.

## Deployment

Unzip and run `npx wrangler deploy` from the project root. No new D1 migration required. Tests did not include live Cloudflare authentication or real-provider cover availability.
