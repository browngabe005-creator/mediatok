# MediaTok v111 — Collection profile alignment

- Combines anime with movies & TV in the Collection-style public profile. Movies, TV and anime remain individually identifiable entries in the database, and can be selected in the same cover picker.
- Keeps Books restricted to reading media (manga, manhwa, manhua, novels, light novels, webnovels, comics and visual novels).
- Removes the separate Anime section from the profile layout and its Arrange Sections dialog. Existing saved anime entries/selections are not deleted.
- Normalizes gutters and poster aspect ratios in the profile shelf.
- Bumps the profile style URL and service-worker cache label to refresh changed assets after deployment.
- All existing profiles, media data, and Library features are left intact. No D1 migration.

## Validation
- Inline and external JavaScript syntax checked.
- Note: local browser checks against the live site's authenticated profile were not run; visual parity with the reference is not yet guaranteed.
