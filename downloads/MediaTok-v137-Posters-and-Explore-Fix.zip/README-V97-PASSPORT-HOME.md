# MediaTok v97 — Passport Home Match

This release changes only the client-side Passport/Collection site style. Existing profiles, APIs, media logs, database migrations, and other site styles are preserved.

## Changes
- Rebuilt the selected Passport home page around the supplied reference: black full-width canvas, left media filter column, prominent poster/recommendation hero, "made from your passport" cards, circle activity cards, people discovery cards, and the right-side circle rail.
- Removed visible scrollbars from Passport rails, chips, horizontal media rows, library pockets, and home carousels while retaining wheel/touch/drag scrolling.
- Right circle rail is capped to six visible members so it does not need its own visible scrollbar.
- Home hero and cards populate from existing MediaTok library/feed data; no database changes are required.
- Passport home remains device-local and does not modify public profile layouts.

## Deploy
Upload/deploy this project exactly as before. No D1 migration is required for v97.
