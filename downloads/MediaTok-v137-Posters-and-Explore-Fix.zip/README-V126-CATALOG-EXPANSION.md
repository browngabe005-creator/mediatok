# MediaTok v126 — Catalog coverage, artwork, and homepage wording

This release preserves the Nova homepage composition and all three UI/profile modes. No D1 migrations, user data deletes, or changes to account tables are included.

## Fixes

- Nova headline explains the product: “Your favorite media. One library.” with explicit anime / movies / TV / manga / novels / games supporting copy.
- Catalog search no longer stops when the local starter/index contains some matches. Third-party catalog results are searched and combined with local matches, and duplicates prefer available artwork.
- Added optional TMDB-backed movie and TV search/browse with page-based results and poster URLs, preserving iTunes and TVmaze search fallback. TMDB is the only full movie browsing source in this release, so wide movie browse requires the existing `TMDB_API_KEY` Worker secret.
- Added `/api/films/browse` and `/api/tv/browse`. For TV without TMDB credentials, the TVmaze paginated show index is used. The new Nova screen-media Explore pages show additional title rows and a Load More button.
- Added MyAnimeList (Jikan `lightnovel` type) as an alternate paginated Light Novel provider when AniList fails or reaches its page window. AniList remains the primary source.
- Webnovel search now combines the directory, public bibliographic hits and the logged/seed catalog rather than returning directory-only matches, so provider covers can fill entries with missing artwork.
- Webnovel snapshots run on a Wrangler custom build step, **including when deploying with `npx wrangler deploy`**. Two public snapshot URLs are tried. If both are unreachable, the previous local snapshot is retained; if none was previously generated, runtime fallback and starter titles remain available. The snapshot source is a bounded public subset, not the complete WebNovel platform.
- New `/api/catalog/coverage` reports how many webnovel directory titles the Worker actually loaded and whether the optional TMDB catalog is configured. No secrets are returned.
- Existing image error recovery and proxies remain in place; missing artwork produces an icon/tile rather than removing a media entry.

## Deploy

From the extracted project root run:

```sh
npx wrangler deploy
```

Wrangler now invokes `node scripts/sync-webnovels.mjs` automatically as part of its configured build. It can take additional time when remote snapshot services are slow. A failed network snapshot never removes a previously generated catalog.

For the full TMDB movie catalog, ensure the Worker already has a TMDB API key configured. If it does not, create your own TMDB API key and install it as a Cloudflare secret **without putting it in a file**:

```sh
npx wrangler secret put TMDB_API_KEY
```

Then deploy again. The secret is optional for TV (TVmaze supplies a fallback) and for single-title movie searches (iTunes supplies a fallback). The full movie browse cannot be populated from iTunes alone.

To diagnose coverage after deploying, visit `https://mediatok.org/api/catalog/coverage`. The `webnovels.availableTitles` field must be checked before claiming that thousands of books are loaded. The TMDB configuration field indicates whether full movie browse is enabled.

## Tests run offline

- `node tests/v126-catalog-coverage.mjs` — movie/TV browse (6,000 mocked titles), key secrecy, TVmaze fallback
- `node tests/catalog-v41.mjs` — existing ten-type search and artwork proxy
- `node tests/v70-lightnovels.mjs` — light novel pagination
- `node tests/v49-webnovels.mjs` — pagination across a **mocked** directory of 12,501 titles
- `node tests/v44-offline-search.mjs` — offline seeded/user catalog
- `python3 tests/v126-screen-browser.py` — directory controls and no horizontal overflow at 1760/960/390 widths
- `python3 tests/v125-ui-browser.py` — default profile and Explore visual regression

**Limits:** Live AniList, TMDB, TVmaze, Google Books, GitHub Pages, and external image-host availability were not tested from this offline workspace. Test fixtures do not represent actual current provider catalog sizes. No claim of an exhaustive catalog or complete image coverage is made.
