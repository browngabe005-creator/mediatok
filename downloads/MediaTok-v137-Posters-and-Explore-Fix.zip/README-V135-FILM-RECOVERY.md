# v135 Film recovery

- Fixes stale busy flag when the screen-directory DOM node changes during a render.
- Adds a bounded, clearly labeled local film index as a last fallback for both film browsing and targeted film search (e.g. Star Wars).
- Existing upstream iTunes/Wikipedia/TMDB paths remain in place; local seed titles have no fabricated artwork or provider IDs.
- Does not change the D1 schema or users/media logs.
- A complete film database still requires a live configured TMDB API key.
