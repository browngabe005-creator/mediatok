# MediaTok v108 — Library Renderer + Collection Profile Cleanup

## Library
- One final active renderer, which does not depend on the older pp101 identity/stats renderer.
- Visible loading, sign-in, error, retry and empty states; async request results guarded against stale navigation.
- Includes All Media, Movies & TV, Anime, Books, Games, searching, filtering, sorting and media details actions.
- The Library now reports errors instead of rendering a blank area. Existing `/api/logs?user=` endpoints are reused.

## Collection Profile
- Added one last loaded stylesheet to reset conflicting width, gutter, border, spacing and panel sizing rules.
- Symmetric content columns, consistent 4-up poster rows and fixed vertical spacing.
- Existing Edit / Choose Media / Arrange Sections controls remain connected to the existing frontend handlers.

## Verification
- `node --check` for modified JS and inline JS: pass.
- `node tests/v96-library.mjs`: pass.
- `node tests/v44-offline-search.mjs`: pass.
- Mocked browser UI test: populated media, category filter, search: pass.
- Live Cloudflare auth, remote D1 and full profile screenshot parity NOT verified.

## Deployment
Deploy the Worker and static public assets together. This release changes the cache name to avoid stale JS/CSS. No new migration.
