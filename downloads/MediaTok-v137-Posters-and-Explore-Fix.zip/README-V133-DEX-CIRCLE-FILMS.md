# MediaTok v133 — Dex empty circle and film fallbacks

- Passport Dex browsing layout: hide the Your Circle rail when not signed in or the signed-in user follows no one; do not hide an existing circle on transient API failure. No follow data modified.
- Film directory without TMDB: expand iTunes browse search rotations to 20 categories including Star Wars; increase returned items per query and keep original artwork URL alternatives rather than relying on one resized image. This is a fallback, not a complete film database.
- Service worker cache bumped and site layout CSS/JS versioned to avoid stale assets.

**Recommended for comprehensive film/TV coverage:** set a valid `TMDB_API_KEY` as a secret in the existing Cloudflare Worker. Movie catalog completeness cannot be guaranteed without a full catalog provider.

No database migrations required. Deploy the full project to the existing Worker.
