# v103 Collection profile visual proportions

Adds `public/profile-collection-v103.css`, loaded after the existing Collection styles.

The stylesheet changes only the selected Collection profile view. It tunes desktop card width (914px), borders (4px), radii (40px), poster grid proportions, section spacing, right-hand circle, typography and hover motion. Includes mobile fallbacks and reduced-motion support. Does not modify database or edit functionality.

**Limitations:** This is a closer reference-based implementation, not a verified pixel-perfect copy. The exact original proprietary font/animation curves cannot be established from screenshots alone. Verify using a browser screenshot at the reference viewport before live deployment.
