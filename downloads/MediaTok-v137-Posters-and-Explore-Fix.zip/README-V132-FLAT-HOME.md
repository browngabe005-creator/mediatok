# MediaTok v132 — Flat Home panels

Removes the Home hero background, border, rounding and shadow; removes the decorative halo fill; flattens the Home right-hand Your Corner and related aside cards, preserving the layout, poster images, content, links and buttons. Existing profile and other page styles, Worker and migrations are unchanged.

The new CSS is loaded last and the service-worker cache key is bumped. Deploy to the existing Cloudflare Worker, refresh, and visually check Home on desktop and mobile.
