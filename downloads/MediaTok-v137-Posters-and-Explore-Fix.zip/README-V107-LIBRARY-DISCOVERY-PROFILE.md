# MediaTok v107 — Library, media discovery, profile grid

- Always show Discover Media in the Collection desktop rail, including Home, Discover Media, Library, People.
- Add a Discover Media action inside the library dashboard.
- Make library loading recheck `/api/me` when session state isn't initialized, display a useful sign-in state, show backend errors, validate response shape, and offer retry/discovery links.
- Add All Media and separate Anime/Books tabs; Books now means reading media only. Preserve every logged item, including games, in the Library.
- Initialize the dashboard on the first populated tab if its previous selection is empty, or All Media for completely empty libraries.
- Narrow the profile display to equal-width columns and consistent poster spacing across stars, Next Up, Movies & TV, Books and Anime. Existing owner media selection/arrangement tools remain.
- Bump service worker cache and JS/CSS URL versions.

This changes only frontend presentation. No migrations or media data changes. The unauthenticated browser and offline API tests cannot verify the user's live session; test the deployed Library with a signed-in member account.
