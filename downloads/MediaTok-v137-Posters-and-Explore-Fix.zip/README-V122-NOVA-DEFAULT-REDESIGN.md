# MediaTok v122 — Nova: new Default site + Default profile

## What this replaces

The visible **Default site interface** and **Default (Original) public profile** are replaced by a new dark media-first design called **Nova**. This is not a color override of the old sidebar/cards: Nova has independent frontend renderers and a dedicated stylesheet. AniList and Collection site modes, and Anime/Collection public profiles, are not switched to Nova.

## New Default site

- Dedicated dark two-level workspace: persistent left navigation, search/notifications header, profile shortcut, and mobile bottom navigation.
- A custom editorial home: featured hero, live recommendation cards, media-type destination tiles, community activity, and quick links.
- A custom Explore view: prominent search, real existing category filters, results, member results, and the existing media-log/details actions. Webnovel and light-novel directory hooks remain available.
- Existing Library API and filter/sort renderer is placed inside the new workspace, with Nova visual styling and the existing retry, empty and error states.
- Community Activity, Forum, Leaderboard, Lists, Settings and Notifications use a new contextual page composition while retaining their existing data and interactive controls.
- New default profile: large editorial media banner, name/avatar/bio/socials, follow/message/share/edit, entry rank, stats, favorites, next-up, in-progress queue, breakdown, community pulse, media tabs, status filters, sorting, and retained music panel when enabled.
- Responsive page compositions, no duplicate legacy mobile navigation, reduced-motion support, and lightweight CSS-only entrance/hover/floating media effects.

## Existing behavior preserved

- User accounts, profiles, follow relationships, forums, private messages, leaderboard, lists, media logs, imports, editor, collection selection and routes continue to use existing functions and Worker APIs.
- The `original` profile-layout value is retained in D1 for backward compatibility, but it renders the new Nova profile. The `default` site-layout value continues to be device-local but renders Nova.
- All Cloudflare Worker backend files and D1 migrations are unchanged.
- AniList and Collection site/profile layout code remains in place and is not restyled by Nova-specific selectors.

## Changed files

- `public/index.html`: route/render wiring and selection labels
- `public/default-nova-v122.js`: new shell, homepage, Explore, profile and community page composition
- `public/default-nova-v122.css`: fully independent dark design system with mobile styles
- `public/service-worker.js`: v122 cache and asset list
- `tests/nova-v122.mjs`: route/action regression checks

## Deploy

From this project's root directory (containing `wrangler.jsonc`):

```bash
npx wrangler deploy
```

No database migration or reset is required. Hard-refresh after the deployment if your old service worker has an active tab open.

## What was tested

- Browser DOM/geometry checks on the new home, profile and Explore page at 1512px, 980/820px and 390px widths; no horizontal overflow in the isolated test harness. These used mock profile/media data and do not establish live API success.
- Node syntax checks for the new JS and existing inline scripts.
- `node tests/nova-v122.mjs`
- `node tests/v44-offline-search.mjs`
- `node tests/v96-library.mjs`
- `node tests/v54-library-server.mjs`

A legacy catalog-cover URL assertion in `tests/catalog-v41.mjs` still fails in the pre-existing offline test environment. That code is not changed in this release.
