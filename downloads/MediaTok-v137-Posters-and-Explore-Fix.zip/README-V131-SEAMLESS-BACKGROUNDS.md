# MediaTok v131 — Seamless navigation chrome

Removed the remaining solid background fills on the Nova desktop left sidebar and top header. Both now inherit the `.nova-app` page background, rather than appearing as separately shaded rectangular strips. This is a CSS-only change to `public/nova-no-boxes-v130.css`; all navigation, forms, media cards, homepage hero artwork, and backend/database code are unchanged.

The service worker cache version was incremented for fresh asset loading. Refresh the page after deployment.
