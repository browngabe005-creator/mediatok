# MediaTok v105 — Library route repair

## Root cause found
The client router explicitly redirected `goView('library')` to the profile when the selected site style was not `passport`. The Library render branch also only handled that one site style. This prevented the Library from opening in Default and Anime site layouts, even with a working API.

## Fix
- All three site layouts can navigate to the Library.
- The Library render branch handles all layouts, and the default sidebar includes a My Library item.
- The Collection dashboard is styled on non-Collection layouts too.
- The first populated medium is selected automatically on opening the Library (instead of forcing empty Movies & TV every time).
- Service worker cache and asset query versions increased to v105.

No database migrations, API changes, or destructive data operations.

## Verification / limitations
JavaScript syntax checked. Authenticated Cloudflare database and production navigation were not available to run end-to-end tests. If library still fails after deployment, capture the exact on-screen error and the `/api/logs?user=...` request status in browser DevTools Network.
