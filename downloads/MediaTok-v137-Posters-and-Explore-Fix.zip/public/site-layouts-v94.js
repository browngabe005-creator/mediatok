/* MediaTok v94: independent Passport-inspired site presentation.
   Client-only, no profile renderer changes and no backend or media-log writes.
   MediaTok is not affiliated with Passport Dexx. */
(function(){
'use strict';
const ppSkin=()=>document.documentElement.dataset.siteSkin==='passport'&&document.documentElement.dataset.profileActive!=='true';
const nav=[['home','home','Hub'],['discover','search','Discover Media'],['library','bookopen','Library'],['lists','grid','Stashes'],['feed','heart','Circle'],['people','user','People'],['forum','forum','Forum'],['leaderboard','trophy','Leaderboard'],['settings','settings','Settings']];
function railButton(view,icon,label){return `<button type="button" class="pp-rail-button ${state.view===view?'is-current':''}" aria-label="${esc(label)}" ${state.view===view?'aria-current="page"':''} onclick="goView('${view}')">${ico(icon)}<span class="pp-rail-label">${esc(label)}</span></button>`}
window.mtSiteShell=function(content){
 if(!ppSkin())return `<div class="layout mt-alt-layout"><aside class="side"><div class="side-title">YOUR SPACE</div>${nav.map(([v,i,l])=>`<button class="side-link ${state.view===v?'active':''}" onclick="goView('${v}')">${ico(i)} ${l}</button>`).join('')}</aside><main class="main">${content}</main></div>`;
 const me=state.me;
 queueMicrotask(()=>window.mtCollectionLoadCircle?.());
 // The home page has a fully independent shell. It must not be placed in the
 // legacy grid; previous releases could collapse the main slot on live pages.
 if(state.view==='home')return `<div class="pp99-shell" id="mtPassportApp">
   <aside class="pp99-nav" aria-label="Main navigation"><div class="pp-rail-brand" title="MediaTok">M</div><div class="pp-rail-links">${nav.filter(([v])=>['home','discover','library','people'].includes(v)).map(([v,i,l])=>railButton(v,i,l)).join('')}</div><div class="pp-rail-bottom"><details class="pp-more"><summary aria-label="More navigation">☰</summary><div class="pp-more-panel">${nav.map(([v,i,l])=>railButton(v,i,l)).join('')}</div></details>${me?`<button class="pp-avatar-button" onclick="location.href='${userLink(me.name)}'" aria-label="View profile">${avatar(me,34)}</button>`:`<button class="pp-rail-button" onclick="login()" aria-label="Sign in">${ico('user')}</button>`}</div></aside>
   <main class="pp99-main" id="ppBody">${content}</main>
   <aside class="pp99-circle" aria-label="People you follow"><h2>your circle</h2><div id="ppCircleMembers" aria-live="polite"></div><button class="pp-circle-more" onclick="goView('people')">meet people ${ico('arrow')}</button></aside>
  </div>`;
 return `<div class="pp-app ${state.view==='home'?'pp-home-app':''}" id="mtPassportApp">
   <aside class="pp-rail" aria-label="Main navigation"><div class="pp-rail-brand" title="MediaTok">M</div><div class="pp-rail-links">${nav.filter(([v])=>['home','discover','library','people'].includes(v)).map(([v,i,l])=>railButton(v,i,l)).join('')}</div><div class="pp-rail-bottom"><details class="pp-more"><summary aria-label="More navigation"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M2 8h20M2 16h20"/></svg></summary><div class="pp-more-panel">${nav.map(([v,i,l])=>railButton(v,i,l)).join('')}<button class="pp-pill" onclick="openProfileImports()">Import media</button><button class="pp-pill" onclick="openProfileLayoutSettings()">Profile layout</button></div></details>${me?`<button class="pp-avatar-button" title="View your profile" aria-label="View your profile" onclick="location.href='${userLink(me.name)}'">${avatar(me,34)}</button>`:`<button class="pp-rail-button" onclick="login()" title="Sign in">${ico('user')}</button>`}</div></aside>
   <div class="pp-page-shell"><div class="pp-browser-header"><div><span class="pp-header-label">MEDIATOK / ${esc(({home:'hub',discover:'search',animanga:'anime & manga',filmstv:'movies & tv',books:'books',library:'library',lists:'stashes',feed:'circle',people:'people'})[state.view]||state.view)}</span><div class="pp-header-title">${esc(({home:'your universe',discover:'find your next obsession',animanga:'anime & manga',filmstv:'movies & tv',books:'books & more',library:'your collection',lists:'your stashes',feed:'your circle',people:'find your people',forum:'community',settings:'settings',leaderboard:'community rankings'})[state.view]||'your space')}</div></div><div class="pp-header-actions">${me?`<button class="pp-small-action" onclick="openProfileImports()" aria-label="Import media">${ico('upload')}</button><button class="pp-small-action" onclick="openProfileLayoutSettings()" aria-label="Change profile layout">${ico('edit')}</button>`:''}<button type="button" class="pp-small-action" onclick="goView('discover')" aria-label="Search media">${ico('search')}</button>${me?`<button type="button" class="pp-small-action" onclick="loadNotifications()" aria-label="Notifications">${ico('bell')}</button>`:''}<button class="pp-small-action pp-header-share" type="button" onclick="mtPassportShare()">${ico('link')}<span>share</span></button></div></div><main class="pp-body" id="ppBody">${content}</main><footer class="pp-footer">MediaTok · Your media, your world · Independent interface style</footer></div>
   <aside class="pp-circle-rail" aria-label="People you follow"><h2>your circle</h2><div id="ppCircleMembers" aria-live="polite"></div><button class="pp-circle-more" onclick="goView('people')">meet people ${ico('arrow')}</button></aside>
  </div>`;
};
window.mtPassportShare=function(){const url=location.href;if(navigator.share)navigator.share({title:'MediaTok',url}).catch(()=>{});else if(navigator.clipboard?.writeText)navigator.clipboard.writeText(url).then(()=>toast('Link copied','success')).catch(()=>toast(url));else toast(url)};
function picksRow(type,count=7){return `<div class="pp-cover-rail" tabindex="0" aria-label="${esc(TYPES[type]?.label||type)} covers">${pickCards(type,count)}</div>`}
function heading(text,sub='',go=''){return `<div class="pp-row-head"><div><h2>${esc(text)}</h2>${sub?`<p>${esc(sub)}</p>`:''}</div>${go?`<button class="pp-see-more" onclick="goView('${go}')">see more ${ico('arrow')}</button>`:''}</div>`}
window.mtSkinHomePage=function(){
 if(!ppSkin())return `<div class="welcome"><h1>Welcome to MediaTok</h1><p>Choose a medium to explore.</p><button class="btn primary" onclick="goView('discover')">Discover</button></div>${pickCards('anime',6)}`;
 return `<div class="pp-home ppx-home">
  <section class="ppx-top-stage" aria-label="MediaTok collection home">
   <nav class="ppx-media-tabs" aria-label="Home media filters">
    <button class="active" type="button" onclick="mtPassportHomeCategory('all')">all</button>
    <button type="button" onclick="mtPassportHomeCategory('game')">games</button>
    <button type="button" onclick="mtPassportHomeCategory('film')">movies</button>
    <button type="button" onclick="mtPassportHomeCategory('novel')">books</button>
    
   </nav>
   <div class="ppx-hero-poster" id="ppHeroVisual" aria-label="Featured media"><div class="ppx-poster-placeholder">✦</div></div>
   <div class="ppx-hero-copy" id="ppPassportHeroCopy"><span class="ppx-hero-kicker">keeps showing up nearby</span><h1>nothing in common. except this</h1><div class="ppx-hero-person"><span class="ppx-mini-avatar">M</span><span><b>your circle</b> is into it</span></div></div>
   <div class="ppx-hero-backdrop" id="ppPassportHeroBackdrop" aria-hidden="true"></div>
  </section>

  <section class="ppx-made-section">
   <div class="ppx-section-title"><span>made from your collection</span><b>for you</b></div>
   <div class="ppx-made-grid" id="ppPassportMadeForYou">
    <button class="ppx-made-card" type="button" onclick="goView('library')"><span><b>your<br>last meal ›</b><small>it's your last night and this is what you asked for.</small></span></button>
    <button class="ppx-made-card" type="button" onclick="goView('people')"><span><b>your<br>character ›</b><small>we compared your whole collection and found your twin.</small></span></button>
   </div>
  </section>

  <section class="ppx-activity-section">
   <div class="ppx-section-title"><span>what they've been into</span><button type="button" onclick="goView('feed')">your circle° ›</button></div>
   <div class="ppx-activity-track" id="ppPersonalShelf" aria-live="polite"><div class="ppx-loading">loading your circle…</div></div>
  </section>

  <section class="ppx-discover-section">
   <div class="ppx-section-title"><span>discover</span><button type="button" onclick="goView('people')">people who get you ›</button></div>
   <div class="ppx-people-track" id="ppPassportPeopleHome"></div>
  </section>
 </div>`;
};
window.mtPassportHomeCategory=function(type){
 if(type==='music'){toast('Music lives on profiles right now. Open a profile or connect Last.fm in Settings.');goView('settings');return;}
 state.type=type;goView('discover');
};
window.mtPassportDiscoverPage=function(){
 const types=state.view==='animanga'?['anime','manga','light-novel']:state.view==='filmstv'?['film','tv']:state.view==='books'?['novel','light-novel','webnovel','comic']:['all','anime','manga','film','tv','novel','light-novel','webnovel','comic','game','visual-novel'];
 state.type=types.includes(state.type)?state.type:types[0];
 const picksType=state.type==='all'?'anime':state.type;
 const directory=state.type==='webnovel'&&!state.search?`<section class="pp-directory"><h2>more webnovels</h2><input class="input" id="mt-webnovel-filter" type="search" placeholder="Find webnovels" oninput="filterWebnovelDirectory(this.value)"><p class="sub" id="mt-webnovel-directory-status">Loading…</p><div id="mt-webnovel-browse" class="mt-webnovel-browse"></div><button class="btn light" id="mt-webnovel-more" hidden onclick="browseMoreWebnovels()">Load more</button></section>`:state.type==='light-novel'&&!state.search?`<section class="pp-directory"><h2>more light novels</h2><input class="input" id="mt-lightnovel-filter" type="search" placeholder="Find light novels" oninput="filterLightNovelDirectory(this.value)"><p class="sub" id="mt-lightnovel-directory-status">Loading…</p><div id="mt-lightnovel-browse" class="mt-webnovel-browse"></div><button class="btn light" id="mt-lightnovel-more" hidden onclick="browseMoreLightNovels()">Load more</button></section>`:'';
 return shell(`<div class="pp-discover"><section class="pp-search-hero"><span class="pp-eyebrow">THE WHOLE UNIVERSE</span><h1>what are you<br><em>into lately?</em></h1><p>every kind of story, all together.</p><form role="search" class="pp-search-field" onsubmit="event.preventDefault();runDiscoverSearch()">${ico('search')}<input id="discoverSearchInput" type="search" placeholder="search titles, creators and members" value="${esc(state.search||'')}" autocomplete="off" maxlength="160" oninput="queueGlobalSearch(this.value)"><button type="submit">search</button></form></section><nav class="pp-filter-chips" aria-label="Filter by medium">${types.map(t=>`<button class="pp-filter-chip ${t===state.type?'selected':''}" onclick="setType('${t}')" aria-pressed="${t===state.type}">${esc(TYPES[t]?.label||t)}</button>`).join('')}</nav><section id="memberSearchResults" aria-live="polite">${renderMemberResults()}</section><div id="searchMessage" class="pp-search-message">${state.results.length?`${state.results.length} matches · tap a cover to explore`:state.search?'Search for media or members above.':'Browse our picks or search for any title.'}</div><div class="pp-search-wall search-results" id="searchResults">${state.results.length?renderResults():state.search?'<div class="pp-empty">Keep typing to find a title.</div>':pickCards(picksType,15)}</div>${directory}</div>`);
};
window.mtPassportLibraryPage=function(){return `<div class="pp-library"><div class="pp-page-title"><span class="pp-eyebrow">YOUR MEDIA, ALL TOGETHER</span><h1>your library</h1><p>every story, place and world you've collected.</p><button class="pp-pill" onclick="openProfileImports()">${ico('upload')} import media</button></div><div id="ppLibraryArea"><div class="mt-space-loader pp-collection-loader" role="status" aria-label="Loading your collection"><div class="mt-loader-cards" aria-hidden="true"><i></i><i></i><i></i></div></div></div></div>`};
window.mtPassportLoadLibrary=async function(){
 const root=document.getElementById('ppLibraryArea');if(!root)return;
 if(!state.me){root.innerHTML=`<div class="pp-empty"><p>Your library is waiting for you.</p><button class="pp-pill primary" onclick="login()">sign in</button></div>`;return;}
 try{
  const data=await api('/api/logs?user='+encodeURIComponent(state.me.name));
  if(!root.isConnected)return;
  const rows=Array.isArray(data)?data:(data.logs||[]);
  window.mtPassportLogs=rows;
  root.innerHTML=`<div class="pp-library-tools"><input type="search" class="pp-library-search" id="ppLibrarySearch" placeholder="find something in your collection…" oninput="mtPassportFilterLibrary()" aria-label="Search your collection"><select id="ppLibraryMedium" aria-label="Medium" onchange="mtPassportFilterLibrary()"><option value="all">all media</option>${Object.entries(TYPES).filter(([k])=>k!=='all').map(([k,v])=>`<option value="${k}">${esc(v.label)}</option>`).join('')}</select><select id="ppLibraryStatus" aria-label="Status" onchange="mtPassportFilterLibrary()"><option value="all">all statuses</option>${[...new Set(['Completed','In progress','Planning','On hold','Dropped',...rows.map(l=>l.status).filter(Boolean)])].map(s=>`<option>${s}</option>`).join('')}</select><select id="ppLibrarySort" aria-label="Sort collection" onchange="mtPassportFilterLibrary()"><option value="recent">recently updated</option><option value="az">title A–Z</option><option value="rating">highest rated</option></select></div><div id="ppLibraryPockets"></div><div id="ppLibraryCount" class="pp-library-count"></div><div class="pp-library-grid" id="ppLibraryGrid"></div>`;
  window.mtPassportFilterLibrary();
 }catch(e){root.innerHTML=`<div class="pp-empty">Couldn't load your collection. <button class="pp-pill" onclick="mtPassportLoadLibrary()">Try again</button></div>`}
};
window.mtPassportFilterLibrary=function(){
 const rows=window.mtPassportLogs||[];const q=(document.getElementById('ppLibrarySearch')?.value||'').trim().toLowerCase(),type=document.getElementById('ppLibraryMedium')?.value||'all',status=document.getElementById('ppLibraryStatus')?.value||'all';
 const filtered=rows.filter(l=>(type==='all'||l.mediaType===type)&&(status==='all'||String(l.status||'').toLowerCase()===status.toLowerCase())&&(!q||String(l.title||'').toLowerCase().includes(q)));
 const sort=document.getElementById('ppLibrarySort')?.value||'recent';filtered.sort((a,b)=>sort==='az'?String(a.title||'').localeCompare(String(b.title||'')):sort==='rating'?(Number(b.rating)||0)-(Number(a.rating)||0):(Number(b.updatedAt||b.updated_at)||0)-(Number(a.updatedAt||a.updated_at)||0));
 const count=document.getElementById('ppLibraryCount'),grid=document.getElementById('ppLibraryGrid');if(!grid)return;if(window.mtPassportLibrarySummary)window.mtPassportLibrarySummary(rows);if(count)count.textContent=`${filtered.length} ${filtered.length===1?'title':'titles'}`;
 grid.innerHTML=filtered.length?filtered.map(l=>`<button type="button" class="pp-library-card pp-lift" onclick="openSiteMediaDetails(this.dataset.type,this.dataset.title,this.dataset.cover,this.dataset.year)" data-type="${esc(l.mediaType||'anime')}" data-title="${esc(l.title||'')}" data-cover="${esc(l.cover||'')}" data-year="${esc(l.year||'')}"><span class="pp-library-art">${l.cover?`<img loading="lazy" src="${esc(catalogDisplaySrc(l.cover))}" alt="" onerror="mediaCoverError(this)" data-artwork-title="${esc(l.title)}" data-media-type="${esc(l.mediaType||'anime')}" data-cover-original="${esc(l.cover)}">`:ico('bookopen')}</span><strong>${esc(l.title||'Untitled')}</strong><small>${esc(l.status||'Logged')}</small></button>`).join(''):`<p class="pp-empty">No matching titles. Try a different filter.</p>`;
};
window.mtPassportPageHeading=function(title,description,inner){return `<section class="pp-embedded-page"><header class="pp-page-title"><span class="pp-eyebrow">MEDIATOK CIRCLE</span><h1>${esc(title)}</h1>${description?`<p>${esc(description)}</p>`:''}</header>${inner}</section>`};
window.mtCollectionLoadCircle=async function(){
 const root=document.getElementById('ppCircleMembers');if(!root)return;
 if(!state.me){root.closest('.pp99-circle,.pp-circle-rail')?.style.setProperty('display','none','important');return;}
 root.innerHTML='<span class="pp-circle-empty">Finding your people…</span>';
 root.closest('.pp99-circle,.pp-circle-rail')?.style.setProperty('display','none','important');
 try{const data=await api('/api/following');if(!root.isConnected)return;
 const users=data.users||[];
 root.closest('.pp99-circle,.pp-circle-rail')?.style.setProperty('display',users.length?'flex':'none','important');
 root.closest('.pp-app')?.classList.toggle('pp-no-circle',!users.length);
 root.innerHTML=users.length?users.slice(0,5).map(u=>`<a class="pp-circle-member" href="${userLink(u.name)}">${avatar({...u,globalName:u.global_name||u.name,avc:u.avatar_url||u.avc},61)}<span>${esc(u.global_name||u.name)}</span></a>`).join(''):'<p class="pp-circle-empty">Follow people to see them here.</p>';
 }catch{if(root.isConnected)root.innerHTML='<button class="pp-pill" onclick="mtCollectionLoadCircle()">Retry your circle</button>';}
};

/* v101: media collection dashboard. Uses the existing log API; no data rewrites. */
const collectionGroup=t=>['film','tv'].includes(t)?'films':t==='anime'?'anime':['manga','manhwa','manhua','novel','light-novel','webnovel','comic','visual-novel'].includes(t)?'books':t==='game'?'games':'other';
let collectionTab='films';
window.mtPassportLibraryPage=function(){return `<div class="pp101-collection"><section class="pp101-stat-grid"><div class="pp101-identity" id="pp101Identity"></div><div class="pp101-stat"><b>always watching something</b><span id="pp101Watched">your film collection</span><div class="pp101-stat-low"><b>movies and series, even split</b><span id="pp101Films">loading your collection…</span></div></div><div class="pp101-stat"><b>your collection in one place</b><span id="pp101Mix">every medium counts</span><div id="pp101Bars" class="pp101-mini-bars"></div></div><div class="pp101-stat pp101-stat-small"><b>all decades welcome</b><span id="pp101Years">from your earliest to latest</span></div><div class="pp101-stat pp101-stat-small"><b>generous so far</b><span id="pp101Ratings">your average rating</span></div><div class="pp101-stat pp101-stat-small"><b>nothing dominates</b><span id="pp101Top">your favorites</span></div></section><div class="pp101-collection-tabs" id="pp101Tabs"></div><div class="pp101-tools"><label>sort <select id="ppLibrarySort" onchange="mtPassportFilterLibrary()"><option value="recent">recent</option><option value="az">title A–Z</option><option value="rating">top rated</option></select></label><label>status <select id="ppLibraryStatus" onchange="mtPassportFilterLibrary()"><option value="all">all</option><option value="Completed">completed</option><option value="In progress">in progress</option><option value="Planning">planned</option><option value="On hold">on hold</option><option value="Dropped">dropped</option></select></label><span class="pp101-tools-right"><input type="search" id="ppLibrarySearch" aria-label="Search collection" placeholder="⌕ search" oninput="mtPassportFilterLibrary()"><button type="button" onclick="openProfileImports()">edit</button></span></div><p class="pp101-tip">select a cover to view or edit it</p><div id="ppLibraryCount" class="pp101-count"></div><div id="ppLibraryGrid" class="pp101-poster-grid"></div><div id="ppLibraryArea" hidden></div></div>`};
window.mtPassportLoadLibrary=async function(){
 const root=document.getElementById('ppLibraryGrid'); if(!root)return;
 root.innerHTML='<p class="pp101-empty" role="status">Loading your library…</p>';
 try{
  let username=state.me?.name;
  if(!username){
   // A returning user's session can finish initializing after the Library route renders.
   const session=await api('/api/me').catch(()=>null);
   const account=session?.user||session?.me||null;
   if(account?.name){state.me=account;username=account.name;}
  }
  if(!root.isConnected)return;
  if(!username){root.innerHTML='<div class="pp101-empty">Sign in to view your saved media. <button type="button" onclick="login()">Sign in</button> <button type="button" onclick="goView(\'discover\')">Find media</button></div>';return;}
  const d=await api('/api/logs?user='+encodeURIComponent(username));
  if(!root.isConnected)return;
  if(d?.error)throw new Error(d.error);
  if(!Array.isArray(d)&&!Array.isArray(d?.logs)&&!Array.isArray(d?.results))throw new Error('The server returned an unexpected library format.');
  window.mtPassportLogs=Array.isArray(d)?d:Array.isArray(d.logs)?d.logs:d.results;
  const tabs=['films','books','anime','games','other'];
  const counts=Object.fromEntries(tabs.map(tab=>[tab,window.mtPassportLogs.filter(r=>r&&collectionGroup(r.mediaType)===tab).length]));
  if(!counts[collectionTab])collectionTab=tabs.find(tab=>counts[tab])||'all';
  mtPassportFilterLibrary();
 }catch(e){if(root.isConnected)root.innerHTML='<div class="pp101-empty" role="alert">Library could not load: '+esc(e?.message||'Unknown error')+' <button type="button" onclick="mtPassportLoadLibrary()">Retry</button> <button type="button" onclick="goView(\'discover\')">Discover media</button></div>';}
};
window.mt101SetTab=function(tab){collectionTab=tab;mtPassportFilterLibrary()};
window.mtPassportFilterLibrary=function(){const rows=(Array.isArray(window.mtPassportLogs)?window.mtPassportLogs:[]).filter(r=>r&&typeof r==='object'),g=collectionGroup;const me=state.me||{};const identity=document.getElementById('pp101Identity');if(!identity)return;
 identity.innerHTML=`<span>${avatar(me,90)}</span><span><strong>${esc(me.globalName||me.name||'your collection')}</strong><small>@${esc(me.name||'member')}</small></span>`;
 const films=rows.filter(r=>g(r.mediaType)==='films'),books=rows.filter(r=>g(r.mediaType)==='books'),games=rows.filter(r=>g(r.mediaType)==='games'),other=rows.filter(r=>g(r.mediaType)==='other');const anime=rows.filter(r=>g(r.mediaType)==='anime');const cards=[['all','all media',rows.length],['films','movies & tv',films.length],['books','books',books.length],['anime','anime',anime.length],['games','games',games.length],['other','other',other.length],['planned','planned',rows.filter(r=>/plan/i.test(r.status||'')).length]];
 document.getElementById('pp101Tabs').innerHTML=cards.map(([key,label,count])=>`<button type="button" class="${collectionTab===key?'selected':''}" onclick="mt101SetTab('${key}')">${label} <span>${count}</span></button>`).join('')+'<button type="button" onclick="goView(\'discover\')">+ discover media</button><button type="button" onclick="goView(\'lists\')">stashes</button>';
 const movieCount=films.filter(r=>r.mediaType==='film').length,showCount=films.filter(r=>r.mediaType==='tv').length;document.getElementById('pp101Films').textContent=movieCount+' movies · '+showCount+' series';document.getElementById('pp101Watched').textContent=films.length+' logged film & TV titles';document.getElementById('pp101Mix').textContent=books.length+' books & illustrated titles';
 document.getElementById('pp101Bars').innerHTML=[films.length,books.length,games.length,other.length].map(n=>`<i style="height:${Math.max(12,Math.round(n/Math.max(1,films.length,books.length,games.length,other.length)*100))}%"></i>`).join('');
 const years=rows.map(r=>Number(r.year)).filter(y=>y>1800&&y<2100).sort((a,b)=>a-b);document.getElementById('pp101Years').textContent=years.length?years[0]+' – '+years[years.length-1]:'no years recorded';const ratings=rows.map(r=>Number(r.rating)).filter(v=>Number.isFinite(v)&&v>0);document.getElementById('pp101Ratings').textContent=ratings.length?(ratings.reduce((a,b)=>a+b,0)/ratings.length).toFixed(1)+' avg · '+ratings.length+' ratings':'no ratings yet';const largest=cards.slice(1,6).sort((a,b)=>b[2]-a[2])[0];document.getElementById('pp101Top').textContent=largest[1]+' · '+largest[2]+' titles';
 const q=document.getElementById('ppLibrarySearch')?.value.trim().toLowerCase()||'',status=document.getElementById('ppLibraryStatus')?.value||'all',sort=document.getElementById('ppLibrarySort')?.value||'recent';let items=rows.filter(r=>(collectionTab==='all'?true:collectionTab==='planned'?/plan/i.test(r.status||''):g(r.mediaType)===collectionTab)&&(status==='all'||String(r.status||'').toLowerCase()===status.toLowerCase())&&(!q||String(r.title||'').toLowerCase().includes(q)));items.sort((a,b)=>sort==='az'?String(a.title||'').localeCompare(String(b.title||'')):sort==='rating'?(Number(b.rating)||0)-(Number(a.rating)||0):(Number(b.updatedAt||b.updated_at)||0)-(Number(a.updatedAt||a.updated_at)||0));document.getElementById('ppLibraryCount').textContent=items.length+' titles';
 document.getElementById('ppLibraryGrid').innerHTML=items.length?items.map(l=>`<button class="pp101-poster" type="button" onclick="openSiteMediaDetails(this.dataset.type,this.dataset.title,this.dataset.cover,this.dataset.year)" data-type="${esc(l.mediaType||'anime')}" data-title="${esc(l.title||'')}" data-cover="${esc(l.cover||'')}" data-year="${esc(l.year||'')}">${l.cover?`<img loading="lazy" src="${esc(catalogDisplaySrc(l.cover))}" alt="${esc(l.title||'')}" onerror="mediaCoverError(this)" data-artwork-title="${esc(l.title||'')}" data-media-type="${esc(l.mediaType||'anime')}">`:`<span class="pp101-no-art">${esc(l.title||'No cover')}</span>`}<span>${esc(l.title||'Untitled')}</span></button>`).join(''):'<p class="pp101-empty">No titles in this section yet.</p>';
};


/* v108: single resilient Library entrypoint. All controls exist before network requests. */
let mt108Rows=[]; let mt108Tab='all'; let mt108Token=0;
window.mtPassportLibraryPage=function(){return `<section class="mt108-library" aria-label="Your media library"><header class="mt108-library-head"><div><span class="mt108-eyebrow">YOUR COLLECTION</span><h1>Library</h1><p>All of your saved titles, in one place.</p></div><button type="button" onclick="goView('discover')">+ Discover media</button></header><nav class="mt108-library-tabs" id="mt108Tabs"><span>Loading categories…</span></nav><div class="mt108-library-tools"><input id="mt108Search" type="search" placeholder="Search your collection" aria-label="Search your collection" oninput="mt108Filter()"><select id="mt108Status" aria-label="Filter status" onchange="mt108Filter()"><option value="all">All statuses</option><option>Completed</option><option>In progress</option><option>Planning</option><option>On hold</option><option>Dropped</option></select><select id="mt108Sort" aria-label="Sort media" onchange="mt108Filter()"><option value="recent">Recently updated</option><option value="az">Title A–Z</option><option value="rating">Highest rated</option></select></div><p class="mt108-count" id="mt108Count"></p><div class="mt108-library-grid" id="mt108Grid"><p class="mt108-message">Loading saved media…</p></div></section>`};
window.mtPassportLoadLibrary=async function(){
 const grid=document.getElementById('mt108Grid');if(!grid)return;
 const token=++mt108Token;grid.innerHTML='<p class="mt108-message" role="status">Loading saved media…</p>';
 try{
  let me=state.me;
  if(!me?.name){const session=await api('/api/me');me=session?.user||session?.me||(session?.name?session:null);if(me?.name)state.me=me;}
  if(token!==mt108Token||!grid.isConnected)return;
  if(!me?.name){grid.innerHTML='<div class="mt108-message">Sign in to see your library. <button type="button" onclick="login()">Sign in</button></div>';document.getElementById('mt108Tabs').innerHTML='';return;}
  const response=await api('/api/logs?user='+encodeURIComponent(me.name));
  if(token!==mt108Token||!grid.isConnected)return;
  if(response?.error)throw Error(String(response.error));
  const data=Array.isArray(response)?response:response?.logs||response?.results||response?.items;
  if(!Array.isArray(data))throw Error('Unexpected library response. Please try again.');
  mt108Rows=data.filter(x=>x&&typeof x==='object'&&x.title);mt108Tab='all';window.mtPassportLogs=mt108Rows;
  mt108Filter();
 }catch(e){if(token!==mt108Token||!grid.isConnected)return;const msg=document.createElement('p');msg.className='mt108-message';msg.textContent='Could not load library: '+(e?.message||'unknown error');grid.replaceChildren(msg);const retry=document.createElement('button');retry.textContent='Retry loading';retry.onclick=()=>mtPassportLoadLibrary();msg.append(' ',retry);const count=document.getElementById('mt108Count');if(count)count.textContent='';}
};
window.mt108SetTab=function(t){mt108Tab=t;mt108Filter()};
window.mt108Filter=function(){
 const grid=document.getElementById('mt108Grid'),tabs=document.getElementById('mt108Tabs');if(!grid||!tabs)return;
 const groups=[['all','All media'],['films','Movies & TV'],['anime','Anime'],['books','Books'],['games','Games']];
 const cat=r=>['film','tv'].includes(r.mediaType)?'films':r.mediaType==='anime'?'anime':['manga','manhwa','manhua','novel','light-novel','webnovel','comic','visual-novel'].includes(r.mediaType)?'books':'games';
 tabs.innerHTML=groups.map(([k,label])=>`<button type="button" class="${mt108Tab===k?'active':''}" onclick="mt108SetTab('${k}')" aria-pressed="${mt108Tab===k}">${label}<small>${k==='all'?mt108Rows.length:mt108Rows.filter(r=>cat(r)===k).length}</small></button>`).join('');
 const q=(document.getElementById('mt108Search')?.value||'').trim().toLowerCase(), status=document.getElementById('mt108Status')?.value||'all',sort=document.getElementById('mt108Sort')?.value||'recent';
 const items=mt108Rows.filter(r=>(mt108Tab==='all'||cat(r)===mt108Tab)&&(!q||String(r.title).toLowerCase().includes(q))&&(status==='all'||String(r.status||'').toLowerCase()===status.toLowerCase()));
 items.sort((a,b)=>sort==='az'?String(a.title).localeCompare(String(b.title)):sort==='rating'?(Number(b.rating)||0)-(Number(a.rating)||0):(Number(b.updatedAt||b.updated_at)||0)-(Number(a.updatedAt||a.updated_at)||0));
 const count=document.getElementById('mt108Count');if(count)count.textContent=items.length+' '+(items.length===1?'title':'titles');
 if(!items.length){grid.innerHTML='<div class="mt108-message">No titles match this view. <button type="button" onclick="goView(\'discover\')">Find media</button></div>';return;}
 grid.innerHTML=items.map(r=>`<button class="mt108-media" type="button" data-type="${esc(r.mediaType||'anime')}" data-title="${esc(r.title)}" data-cover="${esc(r.cover||'')}" data-year="${esc(r.year||'')}" onclick="openSiteMediaDetails(this.dataset.type,this.dataset.title,this.dataset.cover,this.dataset.year)"><span class="mt108-media-art">${r.cover?`<img src="${esc(catalogDisplaySrc(r.cover))}" loading="lazy" alt="" onerror="this.style.display='none'">`:'<span class="mt108-missing">No cover</span>'}</span><strong>${esc(r.title)}</strong><small>${esc(r.status||'Saved')}</small></button>`).join('');
};
window.mtPassportFilterLibrary=function(){window.mt108Filter()};

})();
