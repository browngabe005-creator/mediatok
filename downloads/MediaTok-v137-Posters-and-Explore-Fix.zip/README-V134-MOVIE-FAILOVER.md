# MediaTok v134 — independent film search fallback

The film browse and film search paths in `src/catalog-v41.js` now use an independent Wikipedia-backed film index if iTunes returns no results, times out, or fails. The fallback uses article summaries to exclude obvious non-film results, and accepts missing images without hiding the movie. TMDB remains the preferred high-coverage provider when TMDB_API_KEY is configured; this fallback is **not** a complete film database.

The v133 Dex empty-circle change is retained. No D1 schema changes or data deletion. Service worker cache moved to v134.

Verified: Node JS syntax, simulated failed-iTunes browse, and simulated failed-iTunes direct Star Wars search. Not verified: upstream APIs in live production or browser UI. Test /api/films/browse?offset=0 and /api/search/media?type=film&q=Star%20Wars after deployment, and verify the Films tab.
