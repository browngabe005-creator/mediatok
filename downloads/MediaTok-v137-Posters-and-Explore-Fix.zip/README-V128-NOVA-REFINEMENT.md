# MediaTok v128 — Nova visual polish and movie fallback

Changes built from the v127 Discord-button release:

- Left navigation now has clean, unboxed links; the selected route is still indicated with an accent and slim marker.
- Explore media tabs lose their pill borders while remaining fully functional.
- The oversized outline behind the "Worth your time" results is removed.
- Hover/reveal motion is subtle and respects reduced-motion preference. Continuous poster animation is disabled to reduce CPU/GPU use.
- Recommendation artwork now loads three lookups at a time and queues offscreen artwork during scrolling instead of launching every lookup at once.
- The film-browse API now uses a limited iTunes movie listing when `TMDB_API_KEY` is not configured, instead of returning no movies. Complete movie browsing still needs a valid TMDB key. Existing search routes remain untouched.
- No schema, migration, user data, or profile design changes.

## Deploy
Upload the complete ZIP to the **existing** Cloudflare Worker. Keep existing D1 bindings and secrets. Do not recreate D1. A cache-version bump refreshes the service worker after activation; hard refresh after deployment if needed.

## Checks
Syntax checks for `src/worker.js`, `src/catalog-v41.js`, and inline JavaScript. Visual behavior and availability of live third-party cover providers should be tested after deployment.
