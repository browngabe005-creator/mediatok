# v118 – Your Circle rendering fix

The v117 desktop rail had `display:flex` but no `flex-direction:column` on the fixed right-hand aside. Children flowed horizontally, which squeezed the followers into an invisible/narrow column and made the footer wrap awkwardly. v118 explicitly stacks the heading, member list and footer vertically, preserves the rail on the far right, and displays a Retry control if loading followers fails.

Changed: public/profile-edges-v117.css, public/index.html, public/service-worker.js. No D1 migration required.

The fix is source-level and has not been tested against a live authenticated Cloudflare account.
