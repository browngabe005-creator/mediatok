# v114 — Profile rail placement

- Places the icon navigation sidebar on the far **right** of the Collection profile, after the community circle sidebar, on desktop.
- Removes conflicting `position: fixed; left: 8px` inherited from previous versions. The navigation now occupies its own grid track and does not overlap the profile card.
- Maintains a narrow right navigation on medium viewports and hides the rail on mobile.
- Adds versioned CSS to bust the old asset cache. No D1 changes.

The screenshots are references; exact visual parity with the third-party website is not asserted.
